#include "stdafx.h"
#include <iostream> // declara��es da biblioteca b�sica de entrada e sa�da do C++ (le do teclado e imprime na tela)
#include <fstream>   // fluxo de arquivos
#include <ilcplex/cplex.h>
#include <ilcplex/ilocplex.h>
#include <vector>
#include<algorithm>
#include<ctime>
#include<stdlib.h>
//#include "mochila_estatica_irrestrita.cpp"

using namespace std;

#define RC_EPS 1.0e-6
#define EPS 1.0e-2

//Contador de cada iteracao xdxdxd
time_t t_ini, t_fim; //referente a time.h
double tempo;
double tempototal;

time_t t_ini_int, t_fim_int; //referente a time.h
double tempo_int;
double tempototal_int;

time_t t_aux_1, t_aux_2;
double tempo_aux;
double tempototal_aux;

time_t t_ini_oracle, t_fim_oracle;
double tempo_oracle = 0;



/* para debugar: F5 come�a, em seguida F9 para marcar, depois F10 para percorrer as linhas (n�o entra nas fun��es) ou F11 (para entrar nas f�oes. S� aperta F11 qdo estiver na f��o)*/

/*typedef struct _dadosBarra{
int Nb;
int *Ib;      OBS: antes estava assim, mas como esta usando o cplex, fica mais f�cil programar usando as defini��es de par�metros de acordo com o cplex
int *L;        *L � um vetor que receber� um tamanho espec�fico. Como ainda n�p sei qual �.. ent�o p�e o *
int *e;
} _dadosBarra;*/ // estrutura de dados para a leitura dos objetos em estoque (coloca o typedef antes da struct p/ depois usar apenas _dadosBarra)

typedef struct _dadosBarra {
	IloInt Nb;
	IloNumArray Ib;
	IloNumArray L;
	IloNumArray e;
} _dadosBarra;// estrutura de dados para a leitura dos objetos em estoque (coloca o typedef antes da struct p/ depois usar apenas _dadosBarra)

typedef struct _dadosRetalho {
	IloInt Nr;
	IloNumArray Ir; // indice dos ret. em estoque
	IloNumArray Lr; // comprimento dos retalhos em estoque
	IloNumArray er; // estoque dos ret. 
} _dadosRetalho;// estrutura de dados para a leitura dos retalhos em estoque 

typedef struct _dadosItem {
	IloInt m;
	IloNumArray Indice;
	IloNumArray tam;
	IloNumArray d;
} _dadosItem;// estrutura de dados para a leitura dos itens 

typedef struct _dadosNewRet {
	IloInt tipoR; // qtdde de novos tipos retalhos
	IloNumArray Inr; //�ndice dos novos retalhos
	IloNumArray compRet; // Comprimento dos novos retalhos 
	IloNum qtRet; // quantidade de novos retalhos de cada tipo (U do modelo)
} _dadosNewRet;// estrutura de dados para a leitura dos novos retalhos 

typedef struct _column {
	int length;
	int perda;
	vector<int> item;
} _column;

int auxPosicao = -1; //variavel global q aumenta a medida q eu ganho vetores


typedef struct problema_um {
	IloNum utilidade;  //v[i]
	IloInt peso;         //l[i]
	IloInt posicao;
}*classe;


struct arthur {
	vector<IloNum> padrao; //n precisa usar ponteiro
						   //IloNumArray padrao;
	IloNum barraUsada1;
	IloNum geraretalho1;
	IloNum posicao1;
	IloNum custoMoch1;
	IloNum custoRel1;
	IloNum perda1;
	IloNum length;
	IloNum posicaooriginal; //Criei pra arrumar o bug
	IloNum nbarrausada1;

	//criar a partir daqui as vari�veis do bruno
	IloInt confirma;
	IloInt compNovoRet;
	IloInt length1;

};

bool ordenar(const arthur &x, const arthur &y) { return x.custoRel1 < y.custoRel1; }
bool ordenarback(const arthur &x, const arthur &y) { return x.posicaooriginal < y.posicaooriginal; }//deixar o struct ordenado pra dps inserir no problema mestre



int indice(int num_comp_livres, int *x) {
	int i = num_comp_livres;
	do {
		i--;
	} while ((i>0) && (x[i] == 0));

	if (x[i] == 0) i = -1;
	return(i);
}


int solucao_repetida(int nc, int n, int *x, int **X_nc) {
	bool repetida = 0, igual;
	int i, j;
	i = 0;
	do {
		igual = 1;
		j = 0;

		do {
			if (x[j] == X_nc[i][j]) {
				j++;
			}
			else igual = 0;

		} while (j<n && igual == 1);

		if (igual == 1) {
			repetida = 1;
		}
		else i++;

	} while (repetida == 0 && i<nc);//se tiver solu��o repetida repetida eh igual a 1

	return(repetida);

}

void heapsort(int m, classe dados) 
{//ordenacao por insercao
	int i, j; //�ndices
	double t_utilidade;
	int t_peso;
	int t_posicao;
	
	double pivo;

	for (i = 1; i<m; i++) {
		pivo = (dados[i].utilidade / dados[i].peso);
		t_peso = dados[i].peso;
		t_utilidade = dados[i].utilidade;
		t_posicao = dados[i].posicao;

		j = i - 1;

		while ((j >= 0) && (pivo >(dados[j].utilidade / dados[j].peso))) {
			dados[j + 1].peso = dados[j].peso;
			dados[j + 1].utilidade = dados[j].utilidade;
			dados[j + 1].posicao = dados[j].posicao;
			j = j - 1;
		}
		dados[j + 1].peso = t_peso;
		dados[j + 1].utilidade = t_utilidade;
		dados[j + 1].posicao = t_posicao;
	}
}

void preproc(classe dados, int *newn, int n) {
	//int i = *n;
	int novon = n;

	printf("n=%d", n); //getchar();
	for (int i = 1; i < novon; i++) {
		//printf("i=%d", i); getchar();

		if ((dados[i - 1].peso == dados[i].peso) && (dados[i - 1].utilidade == dados[i].utilidade)) {
			//printf("entrou"); getchar();
			for (int j = i; j < novon - 1; j++) {
				//printf("j=%d", j);
				dados[j].utilidade = dados[j + 1].utilidade;
				dados[j].peso = dados[j + 1].peso;
			}

			i--;
			novon--;
			//printf("newn=%d", novon); getchar();
		}

	}

	*newn = novon;
//	printf("novon=%d", *newn); //getchar();

}

void passo2(int c, int n, int nc, classe dados, int *x, int **X_nc, double *g_nc, double *lim_inff)
{
	int i, j, lin, col, ii, z, pare;
	int largura_util;
	double foaux = 0;
	int k;

	for (lin = 0; lin<nc; lin++) {
		for (col = 0; col<n; col++) {
			X_nc[lin][col] = 0;
		}
		g_nc[lin] = 0;
	}

	largura_util = c;
	for (ii = 0; ii<n; ii++) {
		while (((largura_util - dados[ii].peso) >= 0)) {

			x[ii] = x[ii] + 1;
			largura_util = largura_util - dados[ii].peso;
			foaux = foaux + dados[ii].utilidade;

			if (foaux>g_nc[nc - 1]) {//armazena a solucao
				pare = 0;
				for (i = 0; i<nc; i++) {
					if ((g_nc[i]<foaux) && (pare == 0)) {//armazena a solucao na posicao correspondente
						if (i != (nc - 1)) {
							for (j = (nc - 1); j>i; j--) {
								for (z = 0; z<n; z++) {
									X_nc[j][z] = X_nc[j - 1][z];
								}
								g_nc[j] = g_nc[j - 1];
							}
							for (z = 0; z<n; z++) {
								X_nc[i][z] = x[z];
							}

							g_nc[i] = foaux;

						}//if casado com o else
						else {
							for (z = 0; z<n; z++) {
								X_nc[nc - 1][z] = x[z];
							}
							g_nc[nc - 1] = foaux;
						}//else casado com o if

						pare = 1;
					}//fecha o if q armazena a solucao na posicao correspondente
				}//fecha o for i
			}//fim do if q armazena a solucao
		}//fecha o while
	}//fecha o for ii

	*lim_inff = g_nc[nc - 1];
}


void passo3(int n, int nc, classe dados, int *x, double *lim_inff, int **X_nc, double *g_nc) {
	double g = 0;
	int i, j, z;
	bool repeticao, pare;

	for (i = 0; i<n; i++) {
		g = g + dados[i].utilidade*x[i];
	}
	repeticao = solucao_repetida(nc, n, x, X_nc);//se repeticao for 1 eh porque a solu��o j� est� armazenada

	if (*lim_inff<g && repeticao == 0) {/*executa se n�o tiver solu��o repetida e lim_inff<g,
										neste caso essa solu��o a solu��o encontrada eh melhor que a ultima solu��o e
										portanto inserida na matriz das melhores solu��es excluindo a ultima solu��o */
		pare = 0;
		for (i = 0; i<nc; i++) {
			if (g_nc[i]<g && pare == 0) {

				if (i != (nc - 1)) {
					for (j = nc - 1; j>i; j--) {
						for (z = 0; z<n; z++) {
							X_nc[j][z] = X_nc[j - 1][z];
						}
						g_nc[j] = g_nc[j - 1];
					}
					for (z = 0; z<n; z++) {
						X_nc[i][z] = x[z];
					}
					g_nc[i] = g;
				}
				else {
					for (z = 0; z<n; z++) {
						X_nc[nc - 1][z] = x[z];
					}
					g_nc[nc - 1] = g;
				}
				pare = 1;

			}
		}
		*lim_inff = g_nc[nc - 1];
	}
}

void passo4(int n, int c, classe dados, int *x, double *lim_sup, bool *controla, bool *controlb, int *k) {
	int i, h;

	double largura_util = c;
	*k = indice(n, x);
	if (*k == -1) { //o vetor  � nulo voltou ao n� inicial: A Solu��o � �tima
		*controla = 0;
		*controlb = 0;
	}
	else {
		*lim_sup = 0;
		for (i = 0; i<*k; i++) {
			*lim_sup = *lim_sup + dados[i].utilidade*x[i];
			largura_util = largura_util - (dados[i].peso * x[i]);
		}
		*lim_sup = *lim_sup + dados[*k].utilidade*(x[*k] - 1);
		largura_util = largura_util - (dados[i].peso*(x[*k] - 1));

		h = *k + 1;

		if (h != (n)) {
			*lim_sup = *lim_sup + (dados[h].utilidade / dados[h].peso)*largura_util;
		}
	}
	//printf("limsup=%d", *lim_sup); getchar();
}

void passo5(int c, int n, classe dados, bool *controla, bool *controlb, double *lim_sup, double *lim_inff, int *x, int *k, int nc, int **X_nc, double *g_nc) {

	int i, aux, ii, repeticao, z, j, pare;
	double foaux = 0;
	double largura_util = c;

	if (*lim_sup <= *lim_inff) {
		x[*k] = 0; //zera o �ltimo elemento diferente de do vetor x
		*controlb = 1;//volta ao passo 4
	}

	else {
		x[*k] = x[*k] - 1;
		for (i = 0; i <= *k; i++) {
			largura_util = largura_util - dados[i].peso*x[i];
			foaux = foaux + dados[i].utilidade*x[i];
		}
		for (ii = *k + 1; ii<n; ii++) {

			while (((largura_util - dados[ii].peso) >= 0)) {

				x[ii] = x[ii] + 1;
				largura_util = largura_util - dados[ii].peso;
				foaux = foaux + dados[ii].utilidade;

				repeticao = solucao_repetida(nc, n, x, X_nc);

				if ((foaux>g_nc[nc - 1]) && repeticao == 0) {//armazena a solucao
					pare = 0;
					for (i = 0; i<nc; i++) {
						if ((g_nc[i]<foaux) && (pare == 0)) {//armazena a solucao na posicao correspondente
							if (i != (nc - 1)) {

								for (j = (nc - 1); j>i; j--) {
									for (z = 0; z<n; z++) {
										X_nc[j][z] = X_nc[j - 1][z];
									}
									g_nc[j] = g_nc[j - 1];
								}

								for (z = 0; z<n; z++) X_nc[i][z] = x[z];

								g_nc[i] = foaux;

							}//if casado com o else
							else {

								for (z = 0; z<n; z++)  X_nc[nc - 1][z] = x[z];

								g_nc[nc - 1] = foaux;
							}//else casado com o if

							pare = 1;
						}//fecha o if q armazena a solucao na posicao correspondente
					}//fecha o for i
				}//fim do if q armazena a solucao

			}//fecha o while
		}//fecha o for ii
		*controla = 1;//volta ao passo 3
		*controlb = 0;//sai do passo 4
		*lim_inff = g_nc[nc - 1];
	}
}


void branch_bound_k(classe dados, int n, int c, int *ns_aux, int ***X, double **g_nsaux) {

	int i, j, linha; ///n�mero de itens, capacidade da mochila e nc o n�mero de melhores solu��es a ser determinado(k melhores solu��es)
	double lim_inff = -1000;
	double lim_sup;
	bool controla = 1, controlb = 1;

	int k, nc = *ns_aux;
	int **X_nc;

	int *x;        //vetor da solu��o
	double *g_nc;


	x = (int*)malloc(sizeof(int)*n);

	if (x == NULL) {
		printf("Erro de aloca��o de mem�ria\n\n");
		system("pause");
		exit(1);
	}


	X_nc = (int**)malloc(nc * sizeof(int*));
	for (linha = 0; linha<nc; linha++) {
		X_nc[linha] = (int *)malloc(n * sizeof(int)); // aloca as colunas
	}

	g_nc = (double*)malloc(nc * sizeof(double));

	if ((X_nc == NULL) || (g_nc == NULL)) {
		printf("Erro de aloca��o de mem�ria\n\n");
		system("pause");
		exit(1);
	}


	for (i = 0; i<n; i++) {
		x[i] = 0;
	}

	/********************************************Branch-and-Bound******************************************************/

	passo2(c, n, nc, dados, x, X_nc, g_nc, &lim_inff);
	do {
		passo3(n, nc, dados, x, &lim_inff, X_nc, g_nc);
		do {
			passo4(n, c, dados, x, &lim_sup, &controla, &controlb, &k);

			if (controla == 1 || controlb == 1)
				passo5(c, n, dados, &controla, &controlb, &lim_sup, &lim_inff, x, &k, nc, X_nc, g_nc);

		} while (controlb == 1);
	} while (controla == 1);


	///Variaveis a ser passadas para o principal
	*g_nsaux = g_nc;
	*X = X_nc;


	free(x);
}




/*------------Sa�da - Escrita de dados--------------------*/
void escrita(_dadosBarra *barra, _dadosItem *item, const char *exemplo) {  //fun��o q faz a leitura de dados (coloco o * porque esses valores podem se alterar)

	ofstream Arq(exemplo);// para escrever em um arquivo de leitura

	Arq << barra->Nb;

	for (int j = 0; j<barra->Nb; j++) {
		Arq << barra->Ib[j];
		Arq << barra->L[j];
		Arq << barra->e[j];
	}

	Arq << item->m;  // acesso a qtidde de itens do arquivo de leitura

	for (int i = 0; i<item->m; i++) {
		Arq << item->Indice[i];
		Arq << item->tam[i];
		Arq << item->d[i];

	}
}/*----------------------------------------------*/

 /*-------F� c�lcula o min-------*/
int _fmin(int a, int b) {

	if (a > b) {
		return(b);
	}
	return(a);
}/*---------------------------*/


 /*----Principal---------*/
int main(int argc, char **argv)
{
	ifstream Arq1;
	//Arq1.open("teste3.txt");
	Arq1.open(argv[1]); //teste3
						//IloCplex::Callback 

	double perdatotal50 = 0;
	double qtde_barras_usadas50 = 0;
	double totalusado50 = 0;
	double perdaporcento50 = 0;
	double tempo50 = 0;
	double contadoriteracao50 = 0;

	double contPadroesNovos = 0;
	double contPadroesNovosUsados = 0;
	double contPadroesNovos2 = 0;

	double contPadroesH = 0;
	double contPadroesH2 = 0;
	double contPadroesHomogeneosUsados = 0;
	double contPadroesHomogeneosUsados2 = 0;

	double medioK50 = 0;

	double totalperdaporcento = 0, totalperda = 0;
	double totalbarras_padrao = 0, totalbarras_redu = 0, totalretalhos_tamanho = 0;
	double totaltotalpadrao = 0, totaltotalredu = 0, totaltotalret = 0, totaltotalusado = 0;
	double totalcomp400 = 0, totalcomp500 = 0, totalcomp600 = 0; //retalho gerado
	double totalcomp400ret = 0, totalcomp500ret = 0, totalcomp600ret = 0;

	double totalperdaporcentoI = 0, totalperdaI = 0;
	double totalbarras_padraoI = 0, totalbarras_reduI = 0, totalretalhos_tamanhoI = 0;
	double totaltotalpadraoI = 0, totaltotalreduI = 0, totaltotalretI = 0, totaltotalusadoI = 0;
	double totalcomp400I = 0, totalcomp500I = 0, totalcomp600I = 0; //retalho gerado
	double totalcomp400retI = 0, totalcomp500retI = 0, totalcomp600retI = 0;



	string lixo;

	vector <int> vetorInt; //vetor auxiliar das colunas da solucao continua



						   /* Declara��o de vari�veis do main*/

	_dadosBarra barra;  //a vari�vel barra ir� armazenar os dados de _dadosBarra
	_dadosItem item;    //a vari�vel item ir� armazenar os dados de _dadosItem
	_dadosRetalho retalho;
	_dadosNewRet NRet;
	IloNum alfa1, alfa2, custo;	IloNum custoR;
	alfa1 = 1.0;
	alfa2 = 1.0;
	IloEnv env; // env: var. de ambiente o cplex. Tudo do cplex tem q estar dentro desse ambiente
	cout << "q";
	//leitura(env, & barra, & item, & NRet, & retalho, & alfa1, & alfa2); //& = var no delphi 	

	IloInt kbest, numsol; //kbest numero de solucoes usuarios deseja, numsol numero de solucoes encontradas
	cout << "Quantas solucoes vc deseja obter a cada itera��o (m�ximo)" << endl;
	//cin >> kbest;
	kbest = atoi(argv[2]);

	ofstream Arq2;
	//Arq2.open("MM_K1_U3.txt", ios::app);
	Arq2.open(argv[3]);

	getline(Arq1, lixo); //Ler nome do arquivo
	Arq1 >> item.m; //Ler quantidade de itens

	barra.Nb = 1; //Numero de tipos de barras em estoque
	barra.Ib = IloNumArray(env, barra.Nb); // cria��o de um vetor com os �ndices das barras (o vetor de ind�ces das barras foi criado dentro do ambiente env do cplex e tem tamanho Nb)
	barra.L = IloNumArray(env, barra.Nb);
	barra.e = IloNumArray(env, barra.Nb);

	for (int j = 0; j<barra.Nb; j++) {
		//Arq1 >> barra.Ib[j];
		Arq1 >> barra.L[j]; //Ler tamanho da barra
							//Arq1 >> barra.e[j];
		barra.e[j] = 100000000000;
	}


	//MUDAR ESSA*********************************
	retalho.Nr = 1; //numero de tipos de retalhos
	retalho.Ir = IloNumArray(env, retalho.Nr); // cria��o de um vetor com os �ndices dos retalhos em estoque (o vetor de ind�ces dos retalhos foi criado dentro do ambiente env do cplex e tem tamanho Nr)
	retalho.Lr = IloNumArray(env, retalho.Nr);
	retalho.er = IloNumArray(env, retalho.Nr);

	for (int j = 0; j<retalho.Nr; j++) {
		retalho.Ir[j] = 1;
		retalho.Lr[j] = 400;
		retalho.er[j] = 0; //0 em estoque
	}

	//MUDAR ESSA*********************************
	NRet.tipoR = 1;  // acesso a qtidde de novos tipos de retalhos do arquivo de leitura
	NRet.Inr = IloNumArray(env, NRet.tipoR); // cria��o de um vetor com os �ndices dos novos retalhos (o vetor de ind�ces foi criado dentro do ambiente env do cplex e tem tamanho TipoR)
	NRet.compRet = IloNumArray(env, NRet.tipoR);
	//NRet.qtRet = IloNumArray(env, NRet.tipoR); a

	for (int k = 0; k<NRet.tipoR; k++) {
		NRet.Inr[k] = k;
		NRet.compRet[k] = 400;

	}

	NRet.qtRet = 0; //precisa deixar em 0
					//Arq1 >> NRet.qtRet; //valor de u


					/*---------------------------------*/

					//MUDAR ESSA*********************************
					//item.m=122;  // acesso a qtidde de itens do arquivo de leitura
	item.Indice = IloNumArray(env, item.m); // cria��o de um vetor com os �ndices dos itens (o vetor de ind�ces foi criado dentro do ambiente env do cplex e tem tamanho m)
	item.tam = IloNumArray(env, item.m);
	item.d = IloNumArray(env, item.m);
	for (int pp = 0; pp < 1; pp++) //pp = quantidade de problemas em uma inst�ncia
	{
		for (int i = 0; i < item.m; i++) {
			item.Indice[i] = i;

			Arq1 >> item.tam[i];
			//cout << item.tam[i] << "tam";

			Arq1 >> item.d[i];

			//cout << item.d[i] << "dem" << endl;


		}
		do
		{
			time(&t_ini);

			/* CUTTING-OPTIMIZATION MODEL- Cria o modelo para o Cplex */
			IloModel CutModel(env); // declara��o do modelo a ser resolvido associado ao ambiente
			IloObjective MinPerda = IloAdd(CutModel, IloMinimize(env));  // adiciona um objetivo ao modelo - F� objetivo de minimiza��o associado ao modelo
			IloRangeArray Rest_dem = IloAdd(CutModel, IloRangeArray(env, item.d, item.d)); // Rest_dem � o vetor de resti��es da demanda do modelo (neste caso, =). Esta restri��o est� sendo adicionada ao modelo
			IloRangeArray Rest_est = IloAdd(CutModel, IloRangeArray(env, 0.0, barra.e)); // Rest_est � o vetor de resti��es do estoque padronizado do modelo (neste caso, <=). Esta restri��o est� sendo adicionada ao modelo
			IloRangeArray Rest_ret = IloAdd(CutModel, IloRangeArray(env, 0.0, retalho.er)); // Rest_ret � o vetor de resti��es do estoque de retalhos do modelo (neste caso, <=). Esta restri��o est� sendo adicionada ao modelo
			IloNum estRet;
			//IloNumArray estRet(env, retalho.Nr); // gera um vetor com a qtdde de retalhos de cada tipo (lado direito da �ltima restri��o)
			//cout << "Hello";

			IloNum auxSoma = 0;
			for (int j = 0; j < retalho.Nr; j++) { // sempre tenho que ter a qtdde de retalhos em estoque = a qtidde q pode ser gerada 
				auxSoma = auxSoma + retalho.er[j];
				//estRet[j] = NRet.qtRet - retalho.er[j];
			}
			estRet = NRet.qtRet - auxSoma;
			IloRange Rest_balanco = IloAdd(CutModel, IloRange(env, 0.0, estRet));  // Rest_balanco � o vetor de resti��es do balan�o de estoque do modelo (neste caso, <=). Esta restri��o est� sendo adicionada ao modelo
																				   //env.out() << Rest_balanco;
																				   //IloRangeArray Rest_balanco = IloAdd(CutModel, IloRangeArray(env, 0.0, estRet));
			IloNumVarArray Colunas(env); // vetor que ir� armazenar as colunas (vari�veis de decis�o do modelo)

										 /*Montar a matriz homogenea, com retalhos e padronizados*/
			vector<_column> MATRIZ;

			struct arthur Padroes; //meu struct, usei typedef
			vector <arthur> vetorAux;

			if (retalho.Nr > 0) {
				for (int j = 0; j < retalho.Nr; j++) {


					for (int i = 0; i < item.m; i++) {
						if (retalho.Lr[j] >= item.tam[i]) {

							custoR = retalho.Lr[j] - 1 * item.tam[i];
							//custoR = IloNum(retalho.Lr[j] - _fmin(IloNum(retalho.Lr[j] / item.tam[i]), item.d[i])*item.tam[i]);   // c�lculo da perda para calcular o custo de cada vari�vel 	
							Colunas.add(IloNumVar(MinPerda(custoR) + Rest_dem[i](1) + Rest_ret[j](1) + Rest_balanco(-1))); //calcula os coef. das var. qdo usa ret.e adiciona: custo da var na fo, col. da matriz homogenea, coef. do estoque 	


							//Colunas.add(IloNumVar(MinPerda(custoR) + Rest_dem[i](_fmin(IloNum(retalho.Lr[j] / item.tam[i]), item.d[i])) + Rest_ret[j](1) + Rest_balanco(-1))); //calcula os coef. das var. qdo usa ret.e adiciona: custo da var na fo, col. da matriz homogenea, coef. do estoque 	
							Padroes.custoMoch1 = custoR;

							_column aux;
							Padroes.length = retalho.Lr[j];
							Padroes.length1 = (int) Padroes.length;
							Padroes.padrao.resize(item.m);
							for (int k = 0; k < item.m; k++) {
								Padroes.padrao[k] = 0;
							}
							contPadroesH = contPadroesH + 1;
							Padroes.padrao[i] = 1;
							//Padroes.padrao[i] = _fmin(IloNum(retalho.Lr[j] / item.tam[i]), item.d[i]);
							

							Padroes.perda1 = retalho.Lr[j] - 1 * item.tam[i];
							//Padroes.perda1 = retalho.Lr[j] - _fmin(IloNum(retalho.Lr[j] / item.tam[i]), item.d[i]) * item.tam[i];
							
							Padroes.confirma = 3;
							//vetorAux.push_back(aux);		
							auxPosicao++;
							Padroes.posicaooriginal = auxPosicao;

							vetorAux.push_back(Padroes);

							/*for (int p = 0; p < 5; p++)
							{
								env.out() << Padroes.padrao[p] << " ";
							}
							env.out() << endl;*/
						}
					}
				}
			}


			for (int nb = 0; nb < barra.Nb; nb++) {
				for (int i = 0; i < item.m; i++) {
					custo = barra.L[nb] - 1*item.tam[i];
					//custo = barra.L[nb] - _fmin(IloNum(barra.L[nb] / item.tam[i]), item.d[i])*item.tam[i];   // c�lculo da perda para calcular o custo de cada vari�vel 
					//Colunas.add(IloNumVar(MinPerda(custo) + Rest_dem[i](_fmin(IloNum(barra.L[nb] / item.tam[i]), item.d[i])) + Rest_est[nb](1))); //calcula os coef. das var.: custo da var na fo, col. da matriz homogenea, coef. do estoque e adiciona 
					Colunas.add(IloNumVar(MinPerda(custo) + Rest_dem[i](1) + Rest_est[nb](1)));
					
					Padroes.custoMoch1 = custo;
					_column aux;
					Padroes.length = barra.L[nb];
					Padroes.length1 = Padroes.length;
					Padroes.padrao.resize(item.m); // est� adicionando as colunas na matriz (isso � feito para poder ir adicionando as demais colunas e poder imprimir os padr�es no final)


					auxPosicao++;
					Padroes.posicaooriginal = auxPosicao;
					for (int j = 0; j < item.m; j++) {
						Padroes.padrao[j] = 0;
						
					}
					contPadroesH = contPadroesH + 1;
					Padroes.padrao[i] = 1;
					//Padroes.padrao[i] = _fmin(IloNum(barra.L[nb] / item.tam[i]), item.d[i]);

					Padroes.perda1 = barra.L[nb] - 1 * item.tam[i];

					//Padroes.perda1 = barra.L[nb] - _fmin(IloNum(barra.L[nb] / item.tam[i]), item.d[i])*item.tam[i];
					Padroes.confirma = 1;
					//vetorAux.push_back(aux);
					vetorAux.push_back(Padroes);

				}
			}

			IloCplex ModelCplex(CutModel); // associa��o do modelo todo (associa o modelo ao cplex)

			
										   /// PATTERN-GENERATION PROBLEM - Cria o modelo para a mochila ///

			IloModel ProbMochila(env); // associa��o do modelo de gera��o de colunas ao ambiente. Modelo q gera as novas colunas
			IloObjective MaxUso = IloAdd(ProbMochila, IloMaximize(env));// fo mochila (maximizar o uso da barra)
			IloNumVarArray Var_moch(env, item.m, 0.0, IloInfinity, ILOINT); // declara��o das var. da mochila q incluir� var. inteiras
			IloRangeArray moch_constraint(env); //cria a restri��o da mochila, mas ainda n�o define qual � (ser� criada abaixo, pra cada tipo de barra)
			IloCplex MochilaCplex(ProbMochila); // Cria a vari�vel que ser� associada a mochila 
												//MochilaCplex.setOut(env.getNullStream);
												//MochilaCplex.setParam(IloAlgorithm::setOut);
			ofstream LogFile("LogFile.txt");
			MochilaCplex.setOut(LogFile);

			/// Parametros da mochila

			MochilaCplex.setParam(IloCplex::SolnPoolCapacity, kbest); //aceito no maximo 5 solucoes
			MochilaCplex.setParam(IloCplex::SolnPoolIntensity, 0); //gero mais solucoes que o normal porem nao afeto desempenho
			MochilaCplex.setParam(IloCplex::SolnPoolReplace, 1); //1 = deixa as c melhor resultado na fo


																 /// COLUMN-GENERATION PROCEDURE ///

			IloNumArray price(env, item.m); // vetor auxiliar pra armazenar os custos duais
			IloNumArray newPatt(env, item.m); // cria��o de um vetor com Nb posi��es que ir� armazenar cada cada padr�o de corte proveniente do subproblema (vetor de vetores)


			IloNum custoMoch, valorPad, nbarra, barraUsada, posicao, geraRetalho;
			double custoRel = 0.0;
			double NEWcustoRel;

			double piorcusto = 0.0;
			//int posicaopiorcusto; //Criei mas nem usei :/
			double contadoriteracao = 0;
			tempo = 0;
			Padroes.padrao.resize(newPatt.getSize());
			time(&t_aux_1);
			int kk;
			while (true) {

				vector <arthur> vetorAux2; //esse vetor vai mudar a cada iteracao

										   //	ModelCplex.exportModel("hello.lp");
										   /// OPTIMIZE OVER CURRENT PATTERNS ///
				ModelCplex.solve(); // resolve o prob. mestre
									//cout << "HEHE" << endl;
				
									//	ModelCplex.exportModel("hello.lp");
									//cout << "Problema de corte" << endl;
				contadoriteracao++;
				cout << "Solucao: " << ModelCplex.getObjValue() << endl;
				//cout << "Iteracao " << contadoriteracao << " -> Solucao: " << ModelCplex.getObjValue();
				
				
					

				/// FIND AND ADD A NEW PATTERN ///       
				// PORQUE SOMAR O TAMANHO DO ITEM AO PRICING
				for (int i = 0; i < item.m; i++) { //aqui os valores da solu��o dual negativa (do ModelCplex) s�o copiados no array price
					price[i] = ModelCplex.getDual(Rest_dem[i]) + item.tam[i]; //calcula os multiplicadores Simplex (relacionados a0s itens - (valor_dual)+(tam.item)) 
				}

				MaxUso.setLinearCoefs(Var_moch, price);// o array price � usado para definir coeficientes do objetivo no modelo ProbMochila. Obj da mochila

				custoRel = 0.0;

				for (int j = 0; j < item.m; j++) {
					newPatt[j] = 0;
				}
				
				Padroes.padrao.clear();

				Padroes.padrao.resize((newPatt.getSize()));
				//env.out() << "gera uma coluna para cada tipo de barra" << endl;
				
				time(&t_ini_oracle); //Contar o inicio do oracle

				for (int j = 0; j < barra.Nb; j++) {
					if (barra.e[j] > 0) {

						moch_constraint.clear();
						moch_constraint.add(IloScalProd(item.tam, Var_moch) <= barra.L[j]);
						ProbMochila.add(moch_constraint); // cria a restri��o da mochila
						int m_aux;
						IloNum m_L;
						IloInt m_n;
						m_L = barra.L[j]; //tamanho da barra
						m_n = item.m; //tamanho, n�mero de itens
						problema_um *info = new problema_um[m_n];

						for (int i = 0; i < item.m; i++)
						{
							info[i].peso = item.tam[i]; //restricao
							info[i].utilidade = price[i]; //coef FUNCAO OBJETIVO
							info[i].posicao = i;
						}
						
							
					

						
						int ns_aux = kbest; /*numero de solucoes que usuario escolhe*/
						int **X;
						int c = m_L;
						double *g_nsaux;
						int newn;

						
						heapsort(m_n, info);

						//preproc(info, &newn, m_n);

						m_n = item.m;

						branch_bound_k(info, m_n, c, &ns_aux, &X, &g_nsaux);

						double val = 0;

					

						int a = 0;

						for (int k = 0; k < m_n -1 ; k++) //laco do bubblesort
						{
							for (int j = 0; j < m_n -1; j++) //laco do bubblesort
							{
								if ((info[j].posicao) > (info[j + 1].posicao))
								{
											
									a = info[j].posicao;
									info[j].posicao = info[j+1].posicao;
									info[j+1].posicao = a;

									a = info[j].peso;
									info[j].peso = info[j + 1].peso;
									info[j + 1].peso = a;

									for (int i = 0; i < ns_aux; i++)
									{
										a = X[i][j];
										X[i][j] = X[i][j+1];
										X[i][j+1] = a;
										
									}
								}
							}							
						}
						
						
						

						for (int z = 0; z < ns_aux; z++) //ns_aux = numero de solucoes
						{
							
							
								
								val = 0;
								for (int j = 0; j < m_n; j++)
								{
									
										val += X[z][j] * price[j];
										//cout << "valor" << val << endl;
										//cout << "X" << X[z][j] << "info[j].utilidade" << price[j] << endl;
									
								}
								
								
							
								NEWcustoRel = (double)barra.L[j] - val -ModelCplex.getDual(Rest_est[j]);

						

							if (NEWcustoRel < -RC_EPS || j == 0)
							{

								

								custoRel = NEWcustoRel;
								
								//MochilaCplex.getValues(newPatt, Var_moch, z);// se a sol. n�o for �tima, o padr�o � copiado em newPatt e usado para construir a pr�xima coluna a ser inserida no modelo ModelCplex 
																			 //MochilaCplex.getValues(Padroes.padrao, Var_moch, z);
																			 //env.out() << newPatt << endl;

								
								for (auto p = 0; p < m_n; p++)
								{
									Padroes.padrao[p] = X[z][p];
									//cout << Padroes.padrao[p] << " ";
								}
								
								
									valorPad = 0;
									for (int j = 0; j < m_n; j++) {
										if (X[z][j] != 0) {

											valorPad += X[z][j] * item.tam[j];
										}

									}
								custoMoch = barra.L[j] - valorPad;
								
								//COloquei agora
								Padroes.length = barra.L[j];
								Padroes.length1 = barra.L[j];

								barraUsada = 0; // usado pra indicar se foi obj. padronizado (0) ou retalho (1)
								geraRetalho = 0; // indica que corta uma barra padronizada sem gerar retalho. 

								posicao = j;

								Padroes.custoRel1 = custoRel;
								Padroes.barraUsada1 = 0;
								Padroes.geraretalho1 = 0;
								Padroes.custoMoch1 = custoMoch;
								Padroes.posicao1 = posicao; //de qual barra estou falando
								auxPosicao++;
								Padroes.posicaooriginal = auxPosicao;
								//z pois estou falando 

								
								//cout << endl;
								//vetorAux.push_back(Padroes);
								vetorAux2.push_back(Padroes);
							}
						}
						ProbMochila.remove(moch_constraint);
					}
				}


				time(&t_fim_oracle); //marca o tempo final
									 //tempo = difftime(t_fim, t_ini); //Diferença dos tempos
				tempo_oracle = tempo_oracle + difftime(t_fim_oracle, t_ini_oracle);

				//gera uma coluna para cada tipo de retalho
				
				

				//Prepara a mochila para os objetos reduzidos - novo price
				for (int i = 0; i < item.m; i++) {
					price[i] = ModelCplex.getDual(Rest_dem[i]) + alfa1 * item.tam[i]; //calcula os multiplicadores Simplex, com o (tam.item)*alfa1 
				}

				//Pode tirar linha de baixo, n tem uso
				MaxUso.setLinearCoefs(Var_moch, price);// o array price � usado para definir coeficientes do objetivo no modelo ProbMochila. Obj da mochila
								
				IloNum nbarra_utilizado = 0;
				//gera padr�es de corte para os objetos reduzidos
				for (int j = 0; j < barra.Nb; j++) {
					if (barra.e[j] > 0) {
						if (NRet.tipoR > 0 && NRet.qtRet > 0) {
							for (int k = 0; k < NRet.tipoR; k++) {

								if (NRet.qtRet > 0) {
									nbarra = barra.L[j] - NRet.compRet[k];
									//env.out() << nbarra << endl;
									moch_constraint.clear();
									moch_constraint.add(IloScalProd(item.tam, Var_moch) <= nbarra);
									ProbMochila.add(moch_constraint);

									int m_aux;
									IloNum m_L;
									IloInt m_n;
									m_L = nbarra; //tamanho da barra
									m_n = item.m; //tamanho, n�mero de itens
									problema_um *info = new problema_um[m_n];

									for (int i = 0; i < item.m; i++)
									{
										info[i].peso = item.tam[i];
										info[i].utilidade = price[i];
										info[i].posicao = i;
									}

									int ns_aux = kbest; /*numero de solucoes que usuario escolhe*/
									int **X;
									int c = m_L;
									double *g_nsaux;
									int newn;

									
									
									heapsort(m_n, info);

									//preproc(info, &newn, m_n);

									m_n = item.m;

									branch_bound_k(info, m_n, c, &ns_aux, &X, &g_nsaux);


									double val = 0;
									
									int a = 0;

									for (int k = 0; k < m_n - 1; k++) //laco do bubblesort
									{
										for (int j = 0; j < m_n - 1; j++) //laco do bubblesort
										{
											if ((info[j].posicao) >(info[j + 1].posicao))
											{

												a = info[j].posicao;
												info[j].posicao = info[j + 1].posicao;
												info[j + 1].posicao = a;


												for (int i = 0; i < ns_aux; i++)
												{
													a = X[i][j];
													X[i][j] = X[i][j+1];
													X[i][j+1] = a;

												}
											}
										}
									}

								

									//ProbMochila.add(moch_constraint); // cria a restri��o da mochila
									//MochilaCplex.solve(); //Resolve a gera��o padr�o (mochila) com os coeficientes duais
									//MochilaCplex.populate();
									//numsol = MochilaCplex.getSolnPoolNsolns();
									//	env.out() << "teste ver se esta aqui" << endl;
									for (int z = 0; z < ns_aux; z++) //achar um custo relativo pra cada
									{
											val = 0;
											
											for (int o = 0; o < m_n; o++)
											{
											
												
												if (X[z][o] != 0) {
													
													val += X[z][o] * price[o];
													
												}
											}
											
										
											NEWcustoRel = alfa1 * nbarra - val - ModelCplex.getDual(Rest_est[j]) - ModelCplex.getDual(Rest_balanco);


										if (NEWcustoRel < -RC_EPS)
										{
											custoRel = NEWcustoRel;
											Padroes.compNovoRet = NRet.compRet[k];

											//env.out() << "\n Reduzido Custo Rel: " << custoRel << endl;
											for (auto p = 0; p < m_n; p++) //MochilaCplex.getValues(newPatt, Var_moch)
											{
												Padroes.padrao[p] = X[z][p];
												//env.out() << X[z][p] << " ";
											}

											
											valorPad = 0;
											for (int j = 0; j < item.m; j++) {
												if (X[z][j] != 0) {
													valorPad += X[z][j] * item.tam[j];
												}
											}
											/*for (int i = 0; i<ns_aux; i++)
												free(X[i]);
											free(X);*/

											custoMoch = nbarra - valorPad;
											nbarra_utilizado = nbarra;
											barraUsada = 0; // usado pra indicar se foi obj. padronizado (0) ou retalho (1)
											geraRetalho = 1; // indica que corta uma barra padronizada e gera retalho. 
											posicao = j;

											Padroes.length = barra.L[j];
											Padroes.length1 = barra.L[j];

											//	env.out() << nbarra  << "Hello" << endl; 
											//getchar();
											Padroes.custoRel1 = custoRel;
											Padroes.barraUsada1 = 0;
											Padroes.geraretalho1 = 1;
											Padroes.custoMoch1 = custoMoch;
											Padroes.posicao1 = posicao; //de qual barra estou falando
											auxPosicao++;
											Padroes.posicaooriginal = auxPosicao;
											Padroes.nbarrausada1 = nbarra_utilizado;
											//z pois estou falando 

											//cout << endl;
											//vetorAux.push_back(Padroes);
											vetorAux2.push_back(Padroes);
											//	cout<<"CR (gera)" << custoRel <<endl;
											//	getchar();
										}
									}
									ProbMochila.remove(moch_constraint);
								}
							}
						}
					}
				}


				//cout << newPatt << endl;
				//Prepara a mochila para os objetos retalhos - novo price
				for (int i = 0; i < item.m; i++) {
					price[i] = ModelCplex.getDual(Rest_dem[i]) + alfa2 * item.tam[i]; //calcula os multiplicadores Simplex, com o (tam.item)*alfa2
				}
				MaxUso.setLinearCoefs(Var_moch, price);
				
				
				for (int j = 0; j < retalho.Nr; j++) {
					if (retalho.Nr > 0 && retalho.er[j] > EPS) {
						
							
								moch_constraint.clear();
								moch_constraint.add(IloScalProd(item.tam, Var_moch) <= retalho.Lr[j]);
								ProbMochila.add(moch_constraint); // cria a restri��o da mochila
								//MochilaCplex.solve(); //Resolve a gera��o padr�o (mochila) com os coeficientes duais
								//MochilaCplex.populate();
								
								//numsol = MochilaCplex.getSolnPoolNsolns();

								int m_aux;
								IloNum m_L;
								IloInt m_n;
								m_L = retalho.Lr[j]; //tamanho da barra
								m_n = item.m; //tamanho, n�mero de itens
								problema_um *info = new problema_um[m_n];

								for (int i = 0; i < item.m; i++)
								{
									info[i].peso = item.tam[i];
									info[i].utilidade = price[i];
									info[i].posicao = i;
								}

								int ns_aux = kbest; /*numero de solucoes que usuario escolhe*/
								int **X;
								int c = m_L;
								double *g_nsaux;
								int newn;
								
								

								heapsort(m_n, info);

								//preproc(info, &newn, m_n);

								m_n = item.m;

								branch_bound_k(info, m_n, c, &ns_aux, &X, &g_nsaux);


								/*FILE *arquivo = NULL;
								if ((arquivo = fopen("BB_irrestrito_com_preproc.txt", "a")) == NULL) {
									printf("Erro2");
									system("pause");
									exit(1);
								}*/


								double val = 0;
								


								int a = 0;

								for (int k = 0; k < m_n - 1; k++) //laco do bubblesort
								{
									for (int j = 0; j < m_n - 1; j++) //laco do bubblesort
									{
										if ((info[j].posicao) >(info[j + 1].posicao))
										{

											a = info[j].posicao;
											info[j].posicao = info[j + 1].posicao;
											info[j + 1].posicao = a;


											for (int i = 0; i < ns_aux; i++)
											{
												a = X[i][j + 1];
												X[i][j + 1] = X[i][j];
												X[i][j] = a;

											}
										}
									}
								}




								for (int z = 0; z < ns_aux; z++) //achar um custo relativo pra cada
								{
									val = 0;
									for (int j = 0; j < m_n; j++)
									{
										if (X[z][j] != 0) {
											val += X[z][j] * price[j];
										}
									}
									
									


									NEWcustoRel = alfa2 * retalho.Lr[j] - val - ModelCplex.getDual(Rest_ret[j]) + ModelCplex.getDual(Rest_balanco);
									
									if (NEWcustoRel < -RC_EPS)
									{
										custoRel = NEWcustoRel;
										
										//env.out() << "\nRetalho" << custoRel << endl;
										for (auto p = 0; p < m_n; p++) //MochilaCplex.getValues(newPatt, Var_moch)
										{
											Padroes.padrao[p] = X[z][p];
											//cout << Padroes.padrao[p] << " ";
										}
										
										valorPad = 0;
										for (int j = 0; j < m_n; j++) {
											if (X[z][j] != 0) {

												valorPad += X[z][j] * item.tam[j];
											}

										}

										custoMoch = retalho.Lr[j] - valorPad;

										Padroes.length = retalho.Lr[j];
										Padroes.length1 = retalho.Lr[j];

										barraUsada = 1; // usado pra indicar se foi obj. padronizado (0) ou retalho (1)
										posicao = j;

										Padroes.custoRel1 = custoRel;
										Padroes.barraUsada1 = 1;
										Padroes.geraretalho1 = 1;
										Padroes.custoMoch1 = custoMoch;
										Padroes.posicao1 = posicao; //de qual barra estou falando
										auxPosicao++;
										Padroes.posicaooriginal = auxPosicao;
										//	cout <<"CR retalho = " << custoRel <<endl;
										//	getchar();

										//vetorAux.push_back(Padroes);
										vetorAux2.push_back(Padroes);
									}

								}
								ProbMochila.remove(moch_constraint);
							
						
					}
				}


				numsol = vetorAux2.size();
				sort(vetorAux2.begin(), vetorAux2.end(), ordenar);
				custoRel = vetorAux2[0].custoRel1;
				
			//	cout << "custoRel vale " <<custoRel << endl;
					
				
				if (custoRel > -RC_EPS) {   
				//	cout << getchar();
					//cout << getchar();
					break;
				}
				

				_column aux;
				//IloInt menor = kbest; //garantindo que vai no max ate kbest ou numsol (menor deles)
				//if (numsol < kbest)
					//menor = numsol;

				IloInt menor = numsol;
				vetorAux2.resize(menor);
				//cout << "menor vale " << menor << endl;
				contPadroesNovos = contPadroesNovos + menor; 
				
				for (int z = 0; z < menor; z++)
				{
					//cout << "\nGonna use -> CR: " << vetorAux2[z].custoRel1 << " Pattern -> ";  
					for (int p = 0; p < newPatt.getSize(); p++)
					{
						newPatt[p] = vetorAux2[z].padrao[p];
						//cout << newPatt[p] << " ";
					}
					//getchar();
					//vetorAux[z].perda1 = vetorAux[z].custoMoch1;
					vetorAux2[z].perda1 = vetorAux2[z].custoMoch1;
					if (vetorAux2[z].barraUsada1 == 0) {
						if (vetorAux2[z].geraretalho1 == 0)
						{
							Colunas.add(IloNumVar(MinPerda(vetorAux2[z].custoMoch1) + Rest_dem(newPatt) + Rest_est[vetorAux2[z].posicao1](1)));// adiciona no modelo a coluna da mochila q corta padronizado sem retalho
															
																																			   //vetorAux[z].length = barra.L[vetorAux[z].posicao1];
							vetorAux2[z].length = IloNum(barra.L[vetorAux2[z].posicao1]);
							
							//BRUNO
							//cout << vetorAux2[z].custoMoch1 << "normal" << endl;
							vetorAux2[z].confirma = 1;
							vetorAux2[z].length1 = vetorAux2[z].length;
							
						}
						else {
							Colunas.add(IloNumVar(MinPerda(vetorAux2[z].custoMoch1) + Rest_dem(newPatt) + Rest_est[vetorAux2[z].posicao1](1) + Rest_balanco(1)));// adiciona no modelo a coluna da mochila q corta padronizado com retalho

							//Arq5 << "Padrao reduzido CR: "<< custoRel << endl;																															 //cout << "oi"; getchar(); getchar();
							cout << vetorAux2[z].custoMoch1 << "Padrao reduzidp CR: " << 100 - vetorAux2[z].nbarrausada1 << endl;
							vetorAux2[z].length = IloNum(vetorAux2[z].nbarrausada1);

							//BRUNO
							vetorAux2[z].confirma = 2;
							vetorAux2[z].length1 = barra.L[vetorAux2[z].posicao1];

						}
					}
					else {
						Colunas.add(IloNumVar(MinPerda(vetorAux2[z].custoMoch1) + Rest_dem(newPatt) + Rest_ret[vetorAux2[z].posicao1](1) + Rest_balanco(-1)));// adiciona no modelo a coluna da mochila q corta retalho
																																							  //env.out() << "OPA" << endl; getchar(); getchar();
						//Arq5 << "\nAdd retalho CR " << custoRel << endl;																																  //vetorAux[z].length = retalho.Lr[vetorAux[z].posicao1];
						vetorAux2[z].length = retalho.Lr[vetorAux2[z].posicao1];

						//BRUNO
						vetorAux2[z].confirma = 3;
						vetorAux2[z].length1 = vetorAux2[z].length;
						//vetorAux2[z].compNovoRet = compNovoRetalho;
					

					}
				}
				

				//sort(vetorAux2.begin(), vetorAux2.end(), ordenarback);
				vetorAux.insert(vetorAux.end(), vetorAux2.begin(), vetorAux2.end());
				
				custoRel = 0;
				time(&t_aux_2);
				tempototal_aux = (t_aux_2 - t_aux_1) / double(CLOCKS_PER_SEC) * 1000;

				

			}
				


			time(&t_fim); //marca o tempo final
						  //tempo = difftime(t_fim, t_ini); //Diferença dos tempos
			tempo = (t_fim - t_ini) / double(CLOCKS_PER_SEC) * 1000;

			env.out() << "Tempo total: " << tempo << endl;
			//getchar();
			//getchar();
			double perdatotal = 0, perdaporcento = 0;
			double qtde_barras_usadas = 0;
			double totalusado = 0;

			int totalpadrao = 0, totalredu = 0, totalret = 0; //comprimentos cortados

			double barras_padrao = 0, barras_reduzidas = 0, retalhos_tamanho = 0;

			int comp400 = 0, comp500 = 0, comp600 = 0; //Vari�veis sobre novos retalhos
			int comp400Ret = 0, comp500Ret = 0, comp600Ret = 0; //usar retalhos em estoque


																//VARI�VEIS PROBLEMA INTEIRO
			double perdatotalI = 0, perdaporcentoI = 0;
			double qtde_barras_usadasI = 0;
			double totalusadoI = 0;

			int totalpadraoI = 0, totalreduI = 0, totalretI = 0; //comprimentos cortados

			double barras_padraoI = 0, barras_reduzidasI = 0, retalhos_tamanhoI = 0;

			int comp400I = 0, comp500I = 0, comp600I = 0; //Vari�veis sobre novos retalhos
			int comp400RetI = 0, comp500RetI = 0, comp600RetI = 0; //usar retalhos em estoque


			contadoriteracao50 += contadoriteracao;
			tempototal += tempo;

			//Imprimir tempo do oracle
			ofstream Arq7;
			//Arq7.open("Tempo_oracle.txt", ios::app);
			Arq7.open(argv[4], ios::app);
			Arq7 << tempo_oracle / contadoriteracao << endl; //precisa dividir pelo numero de iteracoes
			Arq7.close();

			//Imprimir tempo total
			ofstream Arq8;
			Arq8.open(argv[5], ios::app);
			//Arq8.open("Tempo_total", ios::app);
			Arq8 << tempo << endl;
			Arq8.close();

			//Imprimir iteracoes
			ofstream Arq9;
			Arq9.open(argv[6], ios::app);
			//Arq9.open("Iteracoes.txt", ios::app);
			Arq9 << contadoriteracao << endl;
			Arq9.close();

			//Imprimir k-medio
			ofstream Arq10;
			Arq10.open(argv[7], ios::app);
			//Arq10.open("Kmedio.txt", ios::app);
			Arq10 << (contPadroesNovos) / (contadoriteracao - 1) << endl;
			Arq10.close();

			//Imprimir perda da solucao relaxada
			ofstream Arq11;
			Arq11.open(argv[8], ios::app);
			//Arq11.open("perda_relaxada.txt", ios::app);
			Arq11 << ModelCplex.getObjValue() << endl;
			Arq11.close();

			Arq2 << "\n\nExemplo " << pp + 1 << ": PROBLEMA RELAXADO" << endl;

			Arq2 << "Tempo: " << tempo << " segundos" << endl;
			Arq2 << "Iteracoes:" << contadoriteracao << endl;
			Arq2 << "Solucao Final: " << ModelCplex.getObjValue() << endl;
			Arq2 << "Padr�es novos: " << contPadroesNovos << endl;
			Arq2 << "Valor m�dio de k: " << (contPadroesNovos) / (contadoriteracao - 1) << endl;

			medioK50 = ((contPadroesNovos) / (contadoriteracao - 1)) + medioK50;

			IloInt auxLuiz = round(contPadroesNovos);

			contPadroesNovos2 = contPadroesNovos + contPadroesNovos2;
			contPadroesNovos = 0;


			for (int i = 0; i < Colunas.getSize(); i++) {
				vetorInt.push_back(0);
				if (ModelCplex.getValue(Colunas[i]) > 1e-6) {

					vetorInt[i] = 1;

					qtde_barras_usadas = qtde_barras_usadas + ModelCplex.getValue(Colunas[i]);
					totalusado = totalusado + vetorAux[i].length1 * ModelCplex.getValue(Colunas[i]);
					perdaporcento = (ModelCplex.getObjValue() / totalusado) * 100;

					if (vetorAux[i].confirma == 1) {
						totalpadrao += vetorAux[i].length1 * ModelCplex.getValue(Colunas[i]);
						barras_padrao += vetorAux[i].perda1*ModelCplex.getValue(Colunas[i]);
						//Arq2 << "Perda: " << vetorAux[i].perda << " X: " << ModelCplex.getValue(Colunas[i]) << endl;
					}


					else if (vetorAux[i].confirma == 2) { //significa objeto reduzido (gera retalho)
						totalredu += vetorAux[i].length1 * ModelCplex.getValue(Colunas[i]);
						if (vetorAux[i].compNovoRet == 400)
							comp400 = comp400 + ModelCplex.getValue(Colunas[i]);
						else if (vetorAux[i].compNovoRet == 500)
							comp500 = comp500 + ModelCplex.getValue(Colunas[i]);
						else
							comp600 = comp600 + ModelCplex.getValue(Colunas[i]);


						barras_reduzidas += vetorAux[i].perda1*ModelCplex.getValue(Colunas[i]);
					}
					else if (vetorAux[i].confirma == 3) {
						totalret += vetorAux[i].length1 * ModelCplex.getValue(Colunas[i]);

						if (vetorAux[i].compNovoRet == 400)
							comp400Ret = comp400Ret + ModelCplex.getValue(Colunas[i]);
						else if (vetorAux[i].compNovoRet == 500)
							comp500Ret = comp500Ret + ModelCplex.getValue(Colunas[i]);
						else
							comp600Ret = comp600Ret + ModelCplex.getValue(Colunas[i]);

						retalhos_tamanho += vetorAux[i].perda1*ModelCplex.getValue(Colunas[i]);
					}
				}


			}

			Arq2 << "\nQuantidade de barras usadas: " << qtde_barras_usadas << endl;

			Arq2 << "\nComprimento Objetos padronizados: " << totalpadrao << endl;
			Arq2 << "Comprimento Objetos reduzidos: " << totalredu << endl;

			Arq2 << "Comprimento total cortado: " << totalusado << endl;

			Arq2 << "\nPerda total: " << ModelCplex.getObjValue() << endl;
			Arq2 << "Perda por cento: " << perdaporcento << endl;

			Arq2 << "\nPerdas de barras padr�o cortadas " << barras_padrao << "\n";
			Arq2 << "Perdas de barras reduzidas cortadas " << barras_reduzidas << "\n";
			Arq2 << "Perdas de retalhos em estoque cortados " << retalhos_tamanho << "\n";



			//Comprimento total cortado
			totaltotalusado += totalusado;
			totaltotalpadrao += totalpadrao;
			totaltotalredu += totalredu;
			totaltotalret += totalret;

			//Comprimentos totais perdidos
			totalbarras_padrao += barras_padrao;
			totalbarras_redu += barras_reduzidas;
			totalretalhos_tamanho += retalhos_tamanho;

			//Perdas
			totalperda += ModelCplex.getObjValue();
			totalperdaporcento += perdaporcento;

			//retalhos gerados
			totalcomp400 += comp400;
			totalcomp500 += comp500;
			totalcomp600 += comp600;

			//Retalhos usados
			totalcomp400ret += comp400Ret;
			totalcomp500ret += comp500Ret;
			totalcomp600ret += comp600Ret;


			Arq2 << "\nExemplo " << pp + 1 << ": PROBLEMA INTEIRO" << endl;
			int contador = 0;

			for (int i = 0; i < Colunas.getSize(); i++)
			{
				cout << vetorInt[i] << " ";
				if (vetorInt[i] == 1)
				{
					contador++;

				}


			}
			int y = 1;
			int t = 3;
			//auxLuiz representa o n�mero de colunas geradas durante a gera��o de colunas (excluindo homogeneos pois s�o gerados previamente)
			IloInt KKK = round(auxLuiz / 50) + 1;
			cout << "auxluiz" << auxLuiz << endl;



			for (int i = contPadroesH; i <Colunas.getSize(); i++)
			{
				if (vetorInt[i] == 0)
				{
					if (i % KKK != 0) //significa que � par
					{
						Colunas[i].setUB(0);
					}

				}

			}

			vetorInt.clear(); //limpar pro proximo vetor



			try
			{
				time(&t_ini_int); //marca o tempo inicial do problema inteiro

				CutModel.add(IloConversion(env, Colunas, ILOINT));
				ModelCplex.setParam(IloCplex::TiLim, 100); //deixa o inteiro gastar no m�ximo 100s o tempo do relaxado
				ModelCplex.setParam(IloCplex::MIPSearch, 1); //1: aplicar branch and cut, 2: busca dinamica 
															 //ModelCplex.exportModel("ARTHUR.lp");
				ModelCplex.solve();
				cout << "FO" << ModelCplex.getObjValue() << endl;


				for (int i = 0; i < Colunas.getSize(); i++)
				{
					if (ModelCplex.getValue(Colunas[i]) > 1e-6)
					{
						if (i > contPadroesH - 1) //significa que um padrao n�o-homogeneo foi usado
						{
							contPadroesNovosUsados++;
						}
						else
							contPadroesHomogeneosUsados++;

						Arq2 << "x_" << i << "\t" << ModelCplex.getValue(Colunas[i]) << "\t";
						for (int j = 0; j < item.m; j++)
						{
							Arq2 << vetorAux[i].padrao[j] << " ";
						}
						Arq2 << "\n";
					}
				}

				//contPadroesHomogeneosUsados = Colunas.getSize() - contPadroesNovosUsados;

				contPadroesHomogeneosUsados2 = contPadroesHomogeneosUsados + contPadroesHomogeneosUsados2;
				contPadroesHomogeneosUsados = 0;


				//contPadroesH - 1;
				contPadroesH2 = contPadroesH - 1 + contPadroesH2;
				contPadroesH = 0;




				time(&t_fim_int);
				tempo_int = (t_fim_int - t_ini_int) / double(CLOCKS_PER_SEC) * 1000;
				tempototal_int += tempo_int;

				Arq2 << "Solucao Final: " << ModelCplex.getObjValue() << endl;
				Arq2 << "Tempo: " << tempo_int << endl;
				env.out() << "Solucao Final: " << ModelCplex.getObjValue() << endl;

				//Imprimir perda da solucao inteira
				ofstream Arq12;
				Arq12.open(argv[9], ios::app);
				//Arq12.open("perda_inteira.txt", ios::app);
				Arq12 << ModelCplex.getObjValue() << endl;
				Arq12.close();

				//Imprimir padroes
				ofstream Arq13;
				Arq13.open(argv[10], ios::app);
				//Arq13.open("pla_MM_U6.csv", ios::app);			

				//P Novos gerados ; P Novos Usados; P Homogeneos gerados; P Homogeneos usados\n";
				Arq13 << contPadroesNovos2 << ";" << contPadroesNovosUsados << ";" << contPadroesH2 << ";" << contPadroesHomogeneosUsados2 << ";";

				for (int i = 0; i < Colunas.getSize(); i++) {
					if (ModelCplex.getValue(Colunas[i]) > 1e-6) {
						qtde_barras_usadasI += ModelCplex.getValue(Colunas[i]);
						//Arq2 << "coluna " << i << "\tcomprimento: " << vetorAux[i].length << "\tperda: " << vetorAux[i].perda;
						//Arq2 << "\n";
						totalusadoI += vetorAux[i].length1 * ModelCplex.getValue(Colunas[i]);
						//Arq2 << "oLa" << vetorAux[i].length1 << endl;;

						perdaporcentoI = (ModelCplex.getObjValue() / totalusadoI) * 100;
						if (vetorAux[i].confirma == 1) {
							totalpadraoI += vetorAux[i].length1 * ModelCplex.getValue(Colunas[i]);
							barras_padraoI += vetorAux[i].perda1*ModelCplex.getValue(Colunas[i]);
							//Arq2 << "Perda: " << vetorAux[i].perda << " X: " << ModelCplex.getValue(Colunas[i]) << endl;
						}


						else if (vetorAux[i].confirma == 2) { //significa objeto reduzido (gera retalho)
							totalreduI += vetorAux[i].length1 * ModelCplex.getValue(Colunas[i]);
							if (vetorAux[i].compNovoRet == 400)
								comp400I = comp400I + ModelCplex.getValue(Colunas[i]);
							else if (vetorAux[i].compNovoRet == 500)
								comp500I = comp500I + ModelCplex.getValue(Colunas[i]);
							else
								comp600I = comp600I + ModelCplex.getValue(Colunas[i]);

							barras_reduzidasI += vetorAux[i].perda1*ModelCplex.getValue(Colunas[i]);
						}
						else if (vetorAux[i].confirma == 3) {
							totalretI += vetorAux[i].length1 * ModelCplex.getValue(Colunas[i]);
							if (vetorAux[i].compNovoRet == 400)
								comp400RetI = comp400RetI + ModelCplex.getValue(Colunas[i]);
							else if (vetorAux[i].compNovoRet == 500)
								comp500RetI = comp500RetI + ModelCplex.getValue(Colunas[i]);
							else
								comp600RetI = comp600RetI + ModelCplex.getValue(Colunas[i]);
							retalhos_tamanhoI += vetorAux[i].perda1*ModelCplex.getValue(Colunas[i]);
						}
					}
				}

				Arq2 << "\nQuantidade de barras usadas: " << qtde_barras_usadasI << endl;

				Arq2 << "\nComprimento Objetos padronizados: " << totalpadraoI << endl;
				Arq2 << "Comprimento Objetos reduzidos: " << totalreduI << endl;
				Arq2 << "Comprimento retalhos: " << totalretI << endl;
				Arq2 << "Comprimento total cortado: " << totalusadoI << endl;

				Arq2 << "\nPerda total: " << ModelCplex.getObjValue() << endl;
				Arq2 << "Perda por cento: " << perdaporcentoI << endl;

				Arq2 << "\nPerdas de barras padr�o cortadas " << barras_padraoI << "\n";



				totaltotalusadoI += totalusadoI;
				totaltotalpadraoI += totalpadraoI;
				totaltotalreduI += totalreduI;
				totaltotalretI += totalretI;

				//Comprimentos totais perdidos
				totalbarras_padraoI += barras_padraoI;
				totalbarras_reduI += barras_reduzidasI;
				totalretalhos_tamanhoI += retalhos_tamanhoI;

				//Perdas
				totalperdaI += ModelCplex.getObjValue();
				totalperdaporcentoI += perdaporcentoI;

				//retalhos gerados
				totalcomp400I += comp400I;
				totalcomp500I += comp500I;
				totalcomp600I += comp600I;

				//Retalhos usados
				totalcomp400retI += comp400RetI;
				totalcomp500retI += comp500RetI;
				totalcomp600retI += comp600RetI;


			}
			catch (IloException& ex) {
				Arq2 << "Error: " << ex << endl;
			}
			catch (...) {
				Arq2 << "Erro" << endl;
			}








		} while (pp < -1);
		//cout << "q" << endl;

	}


	Arq2 << "\n\nDADOS PROBLEMA RELAXADO--------------------------------------------------" << endl;

	Arq2 << "COmprimento total de obj padronizados cortados: " << totaltotalpadrao << endl;
	Arq2 << "COmprimento total de obj padronizado reduzidos cortados: " << totaltotalredu << endl;
	Arq2 << "COmprimento total de retalhos cortados: " << totaltotalret << endl;

	Arq2 << "Comprimento total perdido em obj padronizados: " << totalbarras_padrao << endl;


	Arq2 << "Total perda absoluta: " << totalperda << endl;



	Arq2 << "\n\nDADOS PROBLEMA INTEIRO--------------------------------------------------" << endl;
	Arq2 << "COmprimento total de obj padronizados cortados: " << totaltotalpadraoI << endl;


	Arq2 << "Comprimento total perdido em obj padronizados: " << totalbarras_padraoI << endl;


	Arq2 << "Total perda absoluta: " << totalperdaI << endl;


}
