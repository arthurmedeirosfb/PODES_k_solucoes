//#include "pch.h"
#include "stdafx.h"
#include <iostream> // declarações da biblioteca básica de entrada e saída do C++ (le do teclado e imprime na tela)
#include <fstream>   // fluxo de arquivos
#include <ilcplex/cplex.h>
#include <ilcplex/ilocplex.h>
#include <vector>
#include<algorithm>
#include<ctime>
#include<stdlib.h>
//#include "mochila_estatica_irrestrita.cpp"

using namespace std;

#define RC_EPS 1.0e-6
#define EPS 1.0e-2

//Contador de cada iteracao xdxdxd
time_t t_ini, t_fim; //referente a time.h
double tempo;
double tempototal;

time_t t_ini_int, t_fim_int;
double tempo_int;
double tempototal_int;

time_t t_aux_1, t_aux_2;
double tempo_aux;
double tempototal_aux;

time_t t_ini_oracle, t_fim_oracle;
double tempo_oracle = 0;


/* para debugar: F5 começa, em seguida F9 para marcar, depois F10 para percorrer as linhas (não entra nas funções) ou F11 (para entrar nas fçoes. Só aperta F11 qdo estiver na fção)*/

/*typedef struct _dadosBarra{
int Nb;
int *Ib;      OBS: antes estava assim, mas como esta usando o cplex, fica mais fácil programar usando as definições de parâmetros de acordo com o cplex
int *L;        *L é um vetor que receberá um tamanho específico. Como ainda nãp sei qual é.. então põe o *
int *e;
} _dadosBarra;*/ // estrutura de dados para a leitura dos objetos em estoque (coloca o typedef antes da struct p/ depois usar apenas _dadosBarra)

typedef struct _dadosBarra {
	IloInt Nb;
	IloNumArray Ib;
	IloNumArray L;
	IloNumArray e;
} _dadosBarra;// estrutura de dados para a leitura dos objetos em estoque (coloca o typedef antes da struct p/ depois usar apenas _dadosBarra)

typedef struct _dadosRetalho {
	IloInt Nr;
	IloNumArray Ir; // indice dos ret. em estoque
	IloNumArray Lr; // comprimento dos retalhos em estoque
	IloNumArray er; // estoque dos ret. 
} _dadosRetalho;// estrutura de dados para a leitura dos retalhos em estoque 

typedef struct _dadosItem {
	IloInt m;
	IloNumArray Indice;
	IloNumArray tam;
	IloNumArray d;
} _dadosItem;// estrutura de dados para a leitura dos itens 

typedef struct _dadosNewRet {
	IloInt tipoR; // qtdde de novos tipos retalhos
	IloNumArray Inr; //Índice dos novos retalhos
	IloNumArray compRet; // Comprimento dos novos retalhos 
	IloNum qtRet; // quantidade de novos retalhos de cada tipo (U do modelo)
} _dadosNewRet;// estrutura de dados para a leitura dos novos retalhos 

typedef struct _column {
	int length;
	int perda;
	vector<int> item;
} _column;

int auxPosicao = -1; //variavel global q aumenta a medida q eu ganho vetores





struct arthur {
	vector<IloNum> padrao; //n precisa usar ponteiro
						   //IloNumArray padrao;
	IloNum barraUsada1;
	IloNum geraretalho1;
	IloNum posicao1;
	IloNum custoMoch1;
	IloNum custoRel1;
	IloNum perda1;
	IloNum length;
	IloNum posicaooriginal; //Criei pra arrumar o bug
	IloNum nbarrausada1;

	//criar a partir daqui as variáveis do bruno
	IloInt confirma;
	IloInt compNovoRet;
	IloInt length1;

	IloNum callback_obj;


};

struct arthur copia;
vector <arthur> copia2;
IloNum indicepior;
IloNum porcento = 0.4;

bool ordenar(const arthur &x, const arthur &y) { return x.custoRel1 < y.custoRel1; }
bool ordenarback(const arthur &x, const arthur &y) { return x.posicaooriginal < y.posicaooriginal; }//deixar o struct ordenado pra dps inserir no problema mestre

//ifstream Arq1("teste3.txt");



/*------------Saída - Escrita de dados--------------------*/
void escrita(_dadosBarra *barra, _dadosItem *item, const char *exemplo) {  //função q faz a leitura de dados (coloco o * porque esses valores podem se alterar)

	ofstream Arq(exemplo);// para escrever em um arquivo de leitura

	Arq << barra->Nb;

	for (int j = 0; j < barra->Nb; j++) {
		Arq << barra->Ib[j];
		Arq << barra->L[j];
		Arq << barra->e[j];
	}

	Arq << item->m;  // acesso a qtidde de itens do arquivo de leitura

	for (int i = 0; i < item->m; i++) {
		Arq << item->Indice[i];
		Arq << item->tam[i];
		Arq << item->d[i];

	}
}/*----------------------------------------------*/

 /*-------Fç cálcula o min-------*/
int _fmin(int a, int b) {

	if (a > b) {
		return(b);
	}
	return(a);
}/*---------------------------*/


int qtd_resp = 0;
/*
ILOLAZYCONSTRAINTCALLBACK1(call_teste, IloNumVarArray, vetor )
{
	hasIncumbent();
	cout << "teste";
	add(vetor[0] <= 5);
}

*/

//https://www-01.ibm.com/support/docview.wss?uid=swg21399997&aid=9

IloInt limiteAux = 0;

IloInt abortar = 0;

IloInt contAux;

ILOINCUMBENTCALLBACK4(call_ksolucoes, IloNumVarArray, vetor, IloNum, tam, IloNum, qtd_user, IloCplex, MochilaCplex) //chamado quando e incumbente
{


	IloNum obj_nodes;
	obj_nodes = getBestObjValue();
	cout << "incumbent" << endl;
	IloNum obj_atual = getObjValue();
	//cout << obj_nodes << "obj nodes" << endl;
	//cout << obj_atual << "obj atual " << endl;
	if (obj_nodes >= obj_atual)
	{
		//cout << "aqui?" << endl;
		reject(); //rejeita a solucao atual pois existem nós melhores
		obj_nodes = getBestObjValue();
	}

	if (abortar == 1) //usei essa variável para encerrar o problema da mochila
	{
		//cout << "abortar" << endl;
		abortar = 0;
		abort();
	}
}


ILOLAZYCONSTRAINTCALLBACK7(call_diversificar, IloNumVarArray, vetor, IloNum, tam, IloNum, qtd_user, IloNum, porcento, IloConstraintArray, RESTRICAO, IloModel, ProbMochila, _dadosItem, item)  //
{
	//cout << "qtd_resp vale " << qtd_resp;
	IloNum obj_nodes;
	obj_nodes = getBestObjValue();

	

	if (getObjValue() >= obj_nodes)
	{
		cout << "obj_nodes " << obj_nodes << endl;
		cout << "objvalue" << getObjValue() << endl;


		//cout << "q" << endl;
		//IloCplex MochilaCplex(ProbMochila);
		IloEnv divEnv = getEnv();
		IloConstraint consSoma;
		IloExpr restSoma(divEnv);
		copia.padrao.clear();
		copia.padrao.resize(tam);
		IloInt soma = 0;

		//	cout << "comparando " << qtd_resp << "com" << qtd_user << endl;
			//cout << "contaux" << contAux << endl;

		cout << "contAu vale: " << contAux << endl;
		cout << "qtd_resp vale" << qtd_resp << endl;
		cout << "qtd_resp vale" << qtd_user << endl;


		if (qtd_resp == 0) //adiciona se ainda não tivermos solução
		{
			cout << "entrou aqui " << endl;
			contAux = 0;
			for (int i = 0; i < tam; i++)
			{
				//cout << getValue(vetor[i]) << " ";
				if (getValue(vetor[i]) > RC_EPS)
				{
					copia.padrao[i] = getValue(vetor[i]);
					soma = soma + copia.padrao[i];
					restSoma = restSoma + vetor[i];


				}
			}

			limiteAux = floor(soma * porcento); //arredonda para baixo			
			copia.callback_obj = getObjValue();
			copia2.push_back(copia);

			consSoma = (restSoma <= limiteAux); //restrição pronta


			RESTRICAO.clear();
			RESTRICAO.add(consSoma);
			add(consSoma).end();

			qtd_resp++;

		}



		else if ((qtd_resp < qtd_user) && (contAux == 0))
		{
			IloConstraint consSoma2;
			IloExpr restSoma2(divEnv);
			soma = 0;
			cout << contAux << endl;
			limiteAux = 0;
			cout << "\npadrao" << endl;
			for (int i = 0; i < tam; i++)
			{
				//	cout << getValue(vetor[i]) << " ";
				if (getValue(vetor[i]) > RC_EPS)  //if (getValue(vetor[i]) > 0)
				{
					copia.padrao[i] = getValue(vetor[i]);
					soma = soma + copia.padrao[i];
					restSoma2 += vetor[i];
				}
			}

			limiteAux = floor(soma * porcento);

			copia.callback_obj = getObjValue();
			copia2.push_back(copia);
			consSoma2 = (restSoma2 <= limiteAux);
			RESTRICAO.add(consSoma2);
			add(consSoma2).end();
			qtd_resp++;
			IloInt obj_nodes;
			obj_nodes = getBestObjValue();
			//cout << "hehe" << obj_nodes << endl;

		}

		else //vetor cheio, hora de remover restricoes e abortar a otimização
		{
			contAux = 1;
			abortar = 1;

			for (int i = 0; i < qtd_resp; i++)
			{
				ProbMochila.remove(RESTRICAO[i]);
			}

			RESTRICAO.clear();

			//cout << "Finish" << endl;
		}
	}

	cout << "Sera que vai recomeçar?" << endl;

}




int verificar() //fazer depois, se tiver livre
{

	return 1;
}


/*----Principal---------*/
int main(int argc, char **argv)
{
	ifstream Arq1;
	//Arq1.open("teste3.txt");
	Arq1.open(argv[1]); //teste3
						//IloCplex::Callback 

	double perdatotal50 = 0;
	double qtde_barras_usadas50 = 0;
	double totalusado50 = 0;
	double perdaporcento50 = 0;
	double tempo50 = 0;
	double contadoriteracao50 = 0;

	double contPadroesNovos = 0;
	double contPadroesNovosUsados = 0;
	double contPadroesNovos2 = 0;

	double contPadroesH = 0;
	double contPadroesH2 = 0;
	double contPadroesHomogeneosUsados = 0;
	double contPadroesHomogeneosUsados2 = 0;

	double medioK50 = 0;

	double totalperdaporcento = 0, totalperda = 0;
	double totalbarras_padrao = 0, totalbarras_redu = 0, totalretalhos_tamanho = 0;
	double totaltotalpadrao = 0, totaltotalredu = 0, totaltotalret = 0, totaltotalusado = 0;
	double totalcomp400 = 0, totalcomp500 = 0, totalcomp600 = 0; //retalho gerado
	double totalcomp400ret = 0, totalcomp500ret = 0, totalcomp600ret = 0;

	double totalperdaporcentoI = 0, totalperdaI = 0;
	double totalbarras_padraoI = 0, totalbarras_reduI = 0, totalretalhos_tamanhoI = 0;
	double totaltotalpadraoI = 0, totaltotalreduI = 0, totaltotalretI = 0, totaltotalusadoI = 0;
	double totalcomp400I = 0, totalcomp500I = 0, totalcomp600I = 0; //retalho gerado
	double totalcomp400retI = 0, totalcomp500retI = 0, totalcomp600retI = 0;



	string lixo;

	vector <int> vetorInt; //vetor auxiliar das colunas da solucao continua



						   /* Declaração de variáveis do main*/

	_dadosBarra barra;  //a variável barra irá armazenar os dados de _dadosBarra
	_dadosItem item;    //a variável item irá armazenar os dados de _dadosItem
	_dadosRetalho retalho;
	_dadosNewRet NRet;
	IloNum alfa1, alfa2, custo;	IloNum custoR;
	alfa1 = 1.0;
	alfa2 = 1.0;
	IloEnv env; // env: var. de ambiente o cplex. Tudo do cplex tem q estar dentro desse ambiente
	cout << "q";
	//leitura(env, & barra, & item, & NRet, & retalho, & alfa1, & alfa2); //& = var no delphi 	

	IloInt kbest, numsol; //kbest numero de solucoes usuarios deseja, numsol numero de solucoes encontradas
	cout << "Quantas solucoes vc deseja obter a cada iteração (máximo)" << endl;
	//cin >> kbest;
	kbest = atoi(argv[2]);

	ofstream Arq2;
	//Arq2.open("MM_K1_U3.txt", ios::app);
	Arq2.open(argv[3]);

	getline(Arq1, lixo); //Ler nome do arquivo
	Arq1 >> item.m; //Ler quantidade de itens

	barra.Nb = 1; //Numero de tipos de barras em estoque
	barra.Ib = IloNumArray(env, barra.Nb); // criação de um vetor com os índices das barras (o vetor de indíces das barras foi criado dentro do ambiente env do cplex e tem tamanho Nb)
	barra.L = IloNumArray(env, barra.Nb);
	barra.e = IloNumArray(env, barra.Nb);

	for (int j = 0; j<barra.Nb; j++) {
		//Arq1 >> barra.Ib[j];
		Arq1 >> barra.L[j]; //Ler tamanho da barra
							//Arq1 >> barra.e[j];
		barra.e[j] = 100000000000;
	}


	//MUDAR ESSA*********************************
	retalho.Nr = 1; //numero de tipos de retalhos
	retalho.Ir = IloNumArray(env, retalho.Nr); // criação de um vetor com os índices dos retalhos em estoque (o vetor de indíces dos retalhos foi criado dentro do ambiente env do cplex e tem tamanho Nr)
	retalho.Lr = IloNumArray(env, retalho.Nr);
	retalho.er = IloNumArray(env, retalho.Nr);

	for (int j = 0; j<retalho.Nr; j++) {
		retalho.Ir[j] = 1;
		retalho.Lr[j] = 400;
		retalho.er[j] = 0; //0 em estoque
	}

	//MUDAR ESSA*********************************
	NRet.tipoR = 1;  // acesso a qtidde de novos tipos de retalhos do arquivo de leitura
	NRet.Inr = IloNumArray(env, NRet.tipoR); // criação de um vetor com os índices dos novos retalhos (o vetor de indíces foi criado dentro do ambiente env do cplex e tem tamanho TipoR)
	NRet.compRet = IloNumArray(env, NRet.tipoR);
	//NRet.qtRet = IloNumArray(env, NRet.tipoR); a

	for (int k = 0; k<NRet.tipoR; k++) {
		NRet.Inr[k] = k;
		NRet.compRet[k] = 400;

	}

	NRet.qtRet = 0; //precisa deixar em 0
					//Arq1 >> NRet.qtRet; //valor de u


					/*---------------------------------*/

					//MUDAR ESSA*********************************
					//item.m=122;  // acesso a qtidde de itens do arquivo de leitura
	item.Indice = IloNumArray(env, item.m); // criação de um vetor com os índices dos itens (o vetor de indíces foi criado dentro do ambiente env do cplex e tem tamanho m)
	item.tam = IloNumArray(env, item.m);
	item.d = IloNumArray(env, item.m);
	for (int pp = 0; pp < 1; pp++) //pp = quantidade de problemas em uma instância
	{
		for (int i = 0; i < item.m; i++) {
			item.Indice[i] = i;

			Arq1 >> item.tam[i];
			//cout << item.tam[i] << "tam";

			Arq1 >> item.d[i];

			//cout << item.d[i] << "dem" << endl;


		}

		do
		{
			time(&t_ini);

			/* CUTTING-OPTIMIZATION MODEL- Cria o modelo para o Cplex */
			IloModel CutModel(env); // declaração do modelo a ser resolvido associado ao ambiente
			IloObjective MinPerda = IloAdd(CutModel, IloMinimize(env));  // adiciona um objetivo ao modelo - Fç objetivo de minimização associado ao modelo
			IloRangeArray Rest_dem = IloAdd(CutModel, IloRangeArray(env, item.d, item.d)); // Rest_dem é o vetor de restições da demanda do modelo (neste caso, =). Esta restrição está sendo adicionada ao modelo
			IloRangeArray Rest_est = IloAdd(CutModel, IloRangeArray(env, 0.0, barra.e)); // Rest_est é o vetor de restições do estoque padronizado do modelo (neste caso, <=). Esta restrição está sendo adicionada ao modelo
			IloRangeArray Rest_ret = IloAdd(CutModel, IloRangeArray(env, 0.0, retalho.er)); // Rest_ret é o vetor de restições do estoque de retalhos do modelo (neste caso, <=). Esta restrição está sendo adicionada ao modelo
			IloNum estRet;
			//IloNumArray estRet(env, retalho.Nr); // gera um vetor com a qtdde de retalhos de cada tipo (lado direito da última restrição)
			
			IloNum auxSoma = 0;
			for (int j = 0; j < retalho.Nr; j++) { // sempre tenho que ter a qtdde de retalhos em estoque = a qtidde q pode ser gerada 
				auxSoma = auxSoma + retalho.er[j];
				//estRet[j] = NRet.qtRet - retalho.er[j];
			}
			estRet = NRet.qtRet - auxSoma;
			IloRange Rest_balanco = IloAdd(CutModel, IloRange(env, 0.0, estRet));  // Rest_balanco é o vetor de restições do balanço de estoque do modelo (neste caso, <=). Esta restrição está sendo adicionada ao modelo
																				   //env.out() << Rest_balanco;
																				   //IloRangeArray Rest_balanco = IloAdd(CutModel, IloRangeArray(env, 0.0, estRet));
			IloNumVarArray Colunas(env); // vetor que irá armazenar as colunas (variáveis de decisão do modelo)

										 /*Montar a matriz homogenea, com retalhos e padronizados*/
			vector<_column> MATRIZ;

			struct arthur Padroes; //meu struct, usei typedef
			vector <arthur> vetorAux;

			//cout << "oi";
			if (retalho.Nr > 0) {
				for (int j = 0; j < retalho.Nr; j++) {


					for (int i = 0; i < item.m; i++) {
						if (retalho.Lr[j] >= item.tam[i]) {

							custoR = retalho.Lr[j] - 1 * item.tam[i];
							//custoR = IloNum(retalho.Lr[j] - _fmin(IloNum(retalho.Lr[j] / item.tam[i]), item.d[i])*item.tam[i]);   // cálculo da perda para calcular o custo de cada variável 	
							Colunas.add(IloNumVar(MinPerda(custoR) + Rest_dem[i](1) + Rest_ret[j](1) + Rest_balanco(-1))); //calcula os coef. das var. qdo usa ret.e adiciona: custo da var na fo, col. da matriz homogenea, coef. do estoque 	


							//Colunas.add(IloNumVar(MinPerda(custoR) + Rest_dem[i](_fmin(IloNum(retalho.Lr[j] / item.tam[i]), item.d[i])) + Rest_ret[j](1) + Rest_balanco(-1))); //calcula os coef. das var. qdo usa ret.e adiciona: custo da var na fo, col. da matriz homogenea, coef. do estoque 	
							Padroes.custoMoch1 = custoR;

							_column aux;
							Padroes.length = retalho.Lr[j];
							Padroes.length1 = Padroes.length;
							Padroes.padrao.resize(item.m);
							for (int k = 0; k < item.m; k++) {
								Padroes.padrao[k] = 0;
							}
							contPadroesH = contPadroesH + 1; //padroes homogeneos 
							Padroes.padrao[i] = 1;
							//Padroes.padrao[i] = _fmin(IloNum(retalho.Lr[j] / item.tam[i]), item.d[i]);


							Padroes.perda1 = retalho.Lr[j] - 1 * item.tam[i];
							//Padroes.perda1 = retalho.Lr[j] - _fmin(IloNum(retalho.Lr[j] / item.tam[i]), item.d[i]) * item.tam[i];

							Padroes.confirma = 3;
							//vetorAux.push_back(aux);		
							auxPosicao++;
							Padroes.posicaooriginal = auxPosicao;

							vetorAux.push_back(Padroes);

							/*for (int p = 0; p < 5; p++)
							{
								env.out() << Padroes.padrao[p] << " ";
							}
							env.out() << endl;*/
						}
					}
				}
			}


			//cout << "oi";
			for (int nb = 0; nb < barra.Nb; nb++) {
				for (int i = 0; i < item.m; i++) {
					custo = barra.L[nb] - 1 * item.tam[i];
					//custo = barra.L[nb] - _fmin(IloNum(barra.L[nb] / item.tam[i]), item.d[i])*item.tam[i];   // cálculo da perda para calcular o custo de cada variável 
					//Colunas.add(IloNumVar(MinPerda(custo) + Rest_dem[i](_fmin(IloNum(barra.L[nb] / item.tam[i]), item.d[i])) + Rest_est[nb](1))); //calcula os coef. das var.: custo da var na fo, col. da matriz homogenea, coef. do estoque e adiciona 
					Colunas.add(IloNumVar(MinPerda(custo) + Rest_dem[i](1) + Rest_est[nb](1)));

					Padroes.custoMoch1 = custo;
					_column aux;
					Padroes.length = barra.L[nb];
					Padroes.length1 = Padroes.length;
					Padroes.padrao.resize(item.m); // está adicionando as colunas na matriz (isso é feito para poder ir adicionando as demais colunas e poder imprimir os padrões no final)


					auxPosicao++;
					Padroes.posicaooriginal = auxPosicao;
					for (int j = 0; j < item.m; j++) {
						Padroes.padrao[j] = 0;

					}
					contPadroesH = contPadroesH + 1; //padroes homogeneos 
					Padroes.padrao[i] = 1;
					//Padroes.padrao[i] = _fmin(IloNum(barra.L[nb] / item.tam[i]), item.d[i]);

					Padroes.perda1 = barra.L[nb] - 1 * item.tam[i];

					//Padroes.perda1 = barra.L[nb] - _fmin(IloNum(barra.L[nb] / item.tam[i]), item.d[i])*item.tam[i];
					Padroes.confirma = 1;
					//vetorAux.push_back(aux);
					vetorAux.push_back(Padroes);

				}
			}

			IloCplex ModelCplex(CutModel); // associação do modelo todo (associa o modelo ao cplex)
			
			//ModelCplex.setParam(IloCplex::IntParam::NodeFileInd, 3);
			//ModelCplex.setParam(IloCplex::NumParam::TreLim, 3);
										   /// PATTERN-GENERATION PROBLEM - Cria o modelo para a mochila ///

			IloModel ProbMochila(env); // associação do modelo de geração de colunas ao ambiente. Modelo q gera as novas colunas
			IloObjective MaxUso = IloAdd(ProbMochila, IloMaximize(env));// fo mochila (maximizar o uso da barra)
			IloNumVarArray Var_moch(env, item.m, 0.0, IloInfinity, ILOINT); // declaração das var. da mochila q incluirá var. inteiras
			IloRangeArray moch_constraint(env); //cria a restrição da mochila, mas ainda não define qual é (será criada abaixo, pra cada tipo de barra)
			IloCplex MochilaCplex(ProbMochila); // Cria a variável que será associada a mochila 
												//MochilaCplex.setOut(env.getNullStream);
												//MochilaCplex.setParam(IloAlgorithm::setOut);
			ofstream LogFile("LogFile.txt");
			MochilaCplex.setOut(env.getNullStream());
			ofstream WarningFile("WarningFile.txt");
			MochilaCplex.setWarning(env.getNullStream());

			/// Parametros da mochila

			MochilaCplex.setParam(IloCplex::SolnPoolCapacity, kbest); //aceito no maximo 5 solucoes
			MochilaCplex.setParam(IloCplex::SolnPoolIntensity, 0); //gero mais solucoes que o normal porem nao afeto desempenho
			MochilaCplex.setParam(IloCplex::SolnPoolReplace, 1); //1 = deixa as c melhor resultado na fo

			//MochilaCplex.setParam(IloCplex::Param::MIP::Strategy::HeuristicFreq, -1); //HeurFreq:: - 1
																					  //MochilaCplex.setParam(IloCplex::Param::MIP::Strategy::Probe, 0);
			//MochilaCplex.setParam(IloCplex::Param::MIP::Strategy::RINSHeur, -1);
			//MochilaCplex.setParam(IloCplex::Param::MIP::Strategy::FPHeur, -1);
			
			//MochilaCplex.setParam(IloCplex::Param::MIP::Strategy::Probe, 0);
			
			/*
			MochilaCplex.setParam(IloCplex::HeurFreq, -1);
			MochilaCplex.setParam(IloCplex::Param::MIP::Strategy::RINSHeur, -1);

			MochilaCplex.setParam(IloCplex::Param::MIP::Strategy::LBHeur, -1);

			MochilaCplex.setParam(IloCplex::Param::MIP::Strategy::FPHeur, -1);
			*/

			/*
			https://www.ibm.com/support/knowledgecenter/SSSA5P_12.6.3/ilog.odms.cplex.help/CPLEX/Parameters/topics/LBHeur.html

			https://www.ibm.com/support/knowledgecenter/SSSA5P_12.8.0/ilog.odms.cplex.help/CPLEX/Parameters/topics/RINSHeur.html

			https://www.ibm.com/support/knowledgecenter/SSSA5P_12.6.3/ilog.odms.cplex.help/CPLEX/Parameters/topics/FPHeur.html
			*/


			//MochilaCplex.setParam(IloCplex::IntParam::NodeFileInd, 3);
			//MochilaCplex.setParam(IloCplex::NumParam::TreLim);
									 /// COLUMN-GENERATION PROCEDURE ///

			IloNumArray price(env, item.m); // vetor auxiliar pra armazenar os custos duais
			IloNumArray newPatt(env, item.m); // criação de um vetor com Nb posições que irá armazenar cada cada padrão de corte proveniente do subproblema (vetor de vetores)


			IloNum custoMoch, valorPad, nbarra, barraUsada, posicao, geraRetalho;
			double custoRel = 0.0;
			double NEWcustoRel;

			double piorcusto = 0.0;
			//int posicaopiorcusto; //Criei mas nem usei :/
			double contadoriteracao = 0;
			tempo = 0;
			Padroes.padrao.resize(newPatt.getSize());
			time(&t_aux_1);
			
			int kk;
			while (true) {

				vector <arthur> vetorAux2; //esse vetor vai mudar a cada iteracao

										   //	ModelCplex.exportModel("hello.lp");
										   /// OPTIMIZE OVER CURRENT PATTERNS ///
				ModelCplex.solve(); // resolve o prob. mestre

				contadoriteracao++;


				env.out() << "\n\nSolucao: " << ModelCplex.getObjValue() << endl;




				/// FIND AND ADD A NEW PATTERN ///       
				// PORQUE SOMAR O TAMANHO DO ITEM AO PRICING
				
				for (int i = 0; i < item.m; i++) { //aqui os valores da solução dual negativa (do ModelCplex) são copiados no array price
					price[i] = ModelCplex.getDual(Rest_dem[i]) + item.tam[i]; //calcula os multiplicadores Simplex (relacionados a0s itens - (valor_dual)+(tam.item)) 
				//	cout << price[i] << " ";
				}


				MaxUso.setLinearCoefs(Var_moch, price);// o array price é usado para definir coeficientes do objetivo no modelo ProbMochila. Obj da mochila

				custoRel = 0.0;

				for (int j = 0; j < item.m; j++) {
					newPatt[j] = 0;
				}


				Padroes.padrao.clear();

				Padroes.padrao.resize((newPatt.getSize()));
				//gera uma coluna para cada tipo de barra

				time(&t_ini_oracle); //Contar o inicio do oracle
				
				IloRangeArray moch_constraint(env);


				for (int j = 0; j < barra.Nb; j++) {
					if (barra.e[j] > 0) {


						//barra.L[j]
						moch_constraint.clear();
						moch_constraint.add(IloScalProd(item.tam, Var_moch) <= barra.L[j]);
						ProbMochila.add(moch_constraint); // cria a restrição da mochila

						IloRangeArray teste1(env);

						IloConstraintArray RESTRICAO(env);
						RESTRICAO.clear();

						MochilaCplex.use(call_ksolucoes(env, Var_moch, item.m, kbest, MochilaCplex));

						MochilaCplex.use(call_diversificar(env, Var_moch, item.m, kbest, porcento, RESTRICAO, ProbMochila, item));


						/*MochilaCplex.setParam(IloCplex::Param::Preprocessing::Reduce, 1);
						MochilaCplex.setParam(IloCplex::Symmetry, 0);
						MochilaCplex.setParam(IloCplex::PreInd, 0);


						MochilaCplex.setParam(IloCplex::AdvInd, 0);

						MochilaCplex.setParam(IloCplex::Param::MIP::Strategy::HeuristicFreq, -1); //HeurFreq:: - 1
						//MochilaCplex.setParam(IloCplex::Param::MIP::Strategy::Probe, 0);
						MochilaCplex.setParam(IloCplex::Param::MIP::Strategy::RINSHeur, -1);
						MochilaCplex.setParam(IloCplex::Param::MIP::Strategy::FPHeur, -1);
						*/


						//cout << "qtd_resp" << qtd_resp << endl;
						//cout << "limite aux" << limiteAux << endl;
						//CPX_PREREDUCE_PRIMALONLY(1);
						qtd_resp = 0;
						limiteAux = 0;


						//for (int i = 0; i < qtd_resp; i++)
					//ProbMochila.remove(teste1[i]);

					
						MochilaCplex.solve(); //Resolve a geração padrão (mochila) com os coeficientes duais

						/*for (int i = 0; i < qtd_resp; i++)
						{
							cout << RESTRICAO[i] << endl;
							//ProbMochila.remove(RESTRICAO[i]);

						}*/

						
						RESTRICAO.clear();

						//RESTRICAO.clear();

						//MochilaCplex.populate();
					//	numsol = MochilaCplex.getSolnPoolNsolns();
						numsol = qtd_resp;

						for (int z = 0; z < numsol; z++) //achar um custo relativo pra cada
						{
							cout << "opa" << endl;
							double val = 0;
							for (int p = 0; p < item.m; p++)
							{

								//Padroes.padrao[p] = copia2[z].padrao[p];
								cout << copia2[z].padrao[p] << " ";
								val += copia2[z].padrao[p] * price[p];
							}

							//cout << MaxUso.string
							//NEWcustoRel = (double)barra.L[j] - MochilaCplex.getObjValue(z) - ModelCplex.getDual(Rest_est[j]);
							
							NEWcustoRel = (double)barra.L[j] - val - ModelCplex.getDual(Rest_est[j]);

							//cout << "bARRA" << (double)barra.L[j] << endl;
							//cout << "dual" << ModelCplex.getDual(Rest_est[j]);
							//cout << "NEWcustoRel: " << NEWcustoRel;


							if (NEWcustoRel < -RC_EPS || j == 0)
							{

								custoRel = NEWcustoRel;
								//	env.out() << "Normal " << custoRel << endl;
									//MochilaCplex.getValues(newPatt, Var_moch, z);// se a sol. não for ótima, o padrão é copiado em newPatt e usado para construir a próxima coluna a ser inserida no modelo ModelCplex 
																				 //MochilaCplex.getValues(Padroes.padrao, Var_moch, z);
																				 //env.out() << newPatt << endl;

								valorPad = 0;
								for (int i = 0; i < item.m; i++) {
									valorPad = valorPad + copia2[z].padrao[i] * item.tam[i];   // cálculo da perda gerada pela mochila q será o custo da var. a entrar na base 
									Padroes.padrao[i] = round(copia2[z].padrao[i]);

								}
								custoMoch = barra.L[j] - valorPad;

								//COloquei agora
								Padroes.length = barra.L[j];
								Padroes.length1 = barra.L[j];

								barraUsada = 0; // usado pra indicar se foi obj. padronizado (0) ou retalho (1)
								geraRetalho = 0; // indica que corta uma barra padronizada sem gerar retalho. 

								posicao = j;

								Padroes.custoRel1 = custoRel;
								Padroes.barraUsada1 = 0;
								Padroes.geraretalho1 = 0;
								Padroes.custoMoch1 = custoMoch;
								Padroes.posicao1 = posicao; //de qual barra estou falando
								auxPosicao++;
								Padroes.posicaooriginal = auxPosicao;
								//z pois estou falando 



								//cout << endl;
								//vetorAux.push_back(Padroes);
								vetorAux2.push_back(Padroes);
							}
						}
						ProbMochila.remove(moch_constraint);



						//Padroes.padrao.clear();
						copia2.clear();
						copia2.resize(0);
					}
					//cout << "hello" << endl;
				}

				time(&t_fim_oracle); //marca o tempo final
									 //tempo = difftime(t_fim, t_ini); //DiferenÃ§a dos tempos
				tempo_oracle = tempo_oracle + difftime(t_fim_oracle, t_ini_oracle);


				copia2.clear();
				copia2.resize(0);
				/*
				for (int t = 0; t < copia2.size(); t++)
				{

					cout << "\nPADRAO " << t << "OBJ" << copia2[t].callback_obj << endl;
					for (int i = 0; i < item.m; i++)
					{
						cout << copia2[t].padrao[i] << " ";
					}
				}

				*/
				//env.out() << "Terminando itens\n\n" << endl;
				//getchar();
				//getchar();


				//gera uma coluna para cada tipo de retalho


				//Prepara a mochila para os objetos reduzidos - novo price
				for (int i = 0; i < item.m; i++) {
					price[i] = ModelCplex.getDual(Rest_dem[i]) + alfa1 * item.tam[i]; //calcula os multiplicadores Simplex, com o (tam.item)*alfa1 
					cout << price[i] << " ";
				}
				cout << "tamanho itens" << endl;
				for (int i = 0; i < item.m; i++) {
					cout << item.tam[i] <<" ";
				}
				

				//cout << "\ntamanho barra: " << endl;
				MaxUso.setLinearCoefs(Var_moch, price);// o array price é usado para definir coeficientes do objetivo no modelo ProbMochila. Obj da mochila


				IloNum nbarra_utilizado = 0;
				//gera padrões de corte para os objetos reduzidos
				for (int j = 0; j < barra.Nb; j++) {
					if (barra.e[j] > 0) {
						if (NRet.tipoR > 0 && NRet.qtRet > 0) {
							for (int k = 0; k < NRet.tipoR; k++) {

								if (NRet.qtRet > 0) {
									nbarra = barra.L[j] - NRet.compRet[k];
									//env.out() << nbarra << endl;
									moch_constraint.clear();
									moch_constraint.add(IloScalProd(item.tam, Var_moch) <= nbarra);
									//cout << nbarra << endl;
								//	cout << "arthur" << endl;

									ProbMochila.add(moch_constraint); // cria a restrição da mochila

									IloRangeArray(teste1);
									IloConstraintArray RESTRICAO(env);
									//for (int i = 0; i < qtd_resp; i++)
									//	ProbMochila.remove(RESTRICAO[i]);
									RESTRICAO.clear();


									//MochilaCplex.use(call_diversificar(env, Var_moch, item.m, kbest, porcento, RESTRICAO, ProbMochila, teste1));
									//MochilaCplex.use(call_ksolucoes(env, Var_moch, item.m, kbest,MochilaCplex));

								/*	MochilaCplex.setParam(IloCplex::Param::Preprocessing::Reduce, 1);
									MochilaCplex.setParam(IloCplex::Symmetry, 0);
									MochilaCplex.setParam(IloCplex::PreInd, 0);

									MochilaCplex.setParam(IloCplex::AdvInd, 0);



									MochilaCplex.setParam(IloCplex::Param::MIP::Strategy::HeuristicFreq, -1); //HeurFreq:: - 1
								MochilaCplex.setParam(IloCplex::Param::MIP::Strategy::Probe, 0);
									MochilaCplex.setParam(IloCplex::Param::MIP::Strategy::RINSHeur, -1);
									MochilaCplex.setParam(IloCplex::Param::MIP::Strategy::FPHeur, -1); */
									qtd_resp = 0;


									limiteAux = 0;

									//	cout << "qtd_resp" << qtd_resp << endl;
										//cout << "limite aux" << limiteAux << endl;

									MochilaCplex.solve(); //Resolve a geração padrão (mochila) com os coeficientes duais



									numsol = qtd_resp;
									
									for (int z = 0; z < numsol; z++) //achar um custo relativo pra cada
									{
										cout << "\nopa" << endl;
										IloNum val = 0;
										for (int p = 0; p < item.m; p++)
										{
											cout << copia2[z].padrao[p] << " ";
											//Padroes.padrao[p] = copia2[z].padrao[p];
											val += round(copia2[z].padrao[p]) * price[p];
										}
										//NEWcustoRel = alfa1 * nbarra - MochilaCplex.getObjValue(z) - ModelCplex.getDual(Rest_est[j]) - ModelCplex.getDual(Rest_balanco);
										NEWcustoRel = alfa1 * nbarra - val - ModelCplex.getDual(Rest_est[j]) - ModelCplex.getDual(Rest_balanco);
										cout << "custorel: " << NEWcustoRel << endl;
										/*cout << "alfa1: " << alfa1 << endl;
										cout << "nbarra: " << nbarra << endl;
										cout << "val" << val << endl;
										cout << "dual " << ModelCplex.getDual(Rest_est[j]) << endl;
										cout << "dual balanco " << ModelCplex.getDual(Rest_balanco) << endl;

										*/

										if (NEWcustoRel < -RC_EPS)
										{

											custoRel = NEWcustoRel;
											//	env.out() << "Reduzido " << custoRel << endl;

											Padroes.compNovoRet = NRet.compRet[k];
											//MochilaCplex.getValues(newPatt, Var_moch);// se a sol. não for ótima, o padrão é copiado em newPatt e usado para construir a próxima coluna a ser inserida no modelo ModelCplex 

											valorPad = 0;
											for (int i = 0; i < item.m; i++) {
												Padroes.padrao[i] = round(copia2[z].padrao[i]);

												valorPad = valorPad + Padroes.padrao[i] * item.tam[i];   // cálculo da perda gerada pela mochila q será o custo da var. a entrar na base 
											}
											custoMoch = nbarra - valorPad;
											nbarra_utilizado = nbarra;
											barraUsada = 0; // usado pra indicar se foi obj. padronizado (0) ou retalho (1)
											geraRetalho = 1; // indica que corta uma barra padronizada e gera retalho. 
											posicao = j;

											Padroes.length = barra.L[j];
											Padroes.length1 = barra.L[j];

											//	env.out() << nbarra  << "Hello" << endl; 
											//getchar();
											Padroes.custoRel1 = custoRel;
											Padroes.barraUsada1 = 0;
											Padroes.geraretalho1 = 1;
											Padroes.custoMoch1 = custoMoch;
											Padroes.posicao1 = posicao; //de qual barra estou falando
											auxPosicao++;
											Padroes.posicaooriginal = auxPosicao;
											Padroes.nbarrausada1 = nbarra_utilizado;
											//z pois estou falando 

											//cout << "teste" << endl;

											//cout << endl;
											//vetorAux.push_back(Padroes);
											vetorAux2.push_back(Padroes);
											//	cout<<"CR (gera)" << custoRel <<endl;
											//	getchar();
										}
									}
									ProbMochila.remove(moch_constraint);
								}
								copia2.clear();
								copia2.resize(0);

							}
						}
					}
				}


				copia2.clear();
				copia2.resize(0);



/*
				env.out() << "Terminando retalhos\n\n" << endl;
				getchar();
				getchar();

				*/
				//cout << newPatt << endl;
				//Prepara a mochila para os objetos retalhos - novo price



				for (int i = 0; i < item.m; i++) {
					price[i] = ModelCplex.getDual(Rest_dem[i]) + alfa2 * item.tam[i]; //calcula os multiplicadores Simplex, com o (tam.item)*alfa2
				}

				MaxUso.setLinearCoefs(Var_moch, price);



				for (int j = 0; j < retalho.Nr; j++) {
					if (retalho.Nr > 0 && retalho.er[j] > EPS) {
						
								moch_constraint.clear();
								moch_constraint.add(IloScalProd(item.tam, Var_moch) <= retalho.Lr[j]);
								ProbMochila.add(moch_constraint); // cria a restrição da mochila
								
								//MochilaCplex.populate();
								

								IloRangeArray(teste1);
								IloConstraintArray RESTRICAO(env);
								RESTRICAO.clear();
								//MochilaCplex.use(call_diversificar(env, Var_moch, item.m, kbest, porcento, RESTRICAO, ProbMochila, teste1));
								qtd_resp = 0;
								limiteAux = 0;

								MochilaCplex.solve(); //Resolve a geração padrão (mochila) com os coeficientes duais

								numsol = qtd_resp;

								for (int z = 0; z < numsol; z++) //achar um custo relativo pra cada
								{
									double val = 0;
									for (int p = 0; p < item.m; p++)
									{
										//Padroes.padrao[p] = copia2[z].padrao[p];
										val += copia2[z].padrao[p] * price[p];
									}

									NEWcustoRel = alfa2 * retalho.Lr[j] - val - ModelCplex.getDual(Rest_ret[j]) + ModelCplex.getDual(Rest_balanco);
									
									if (NEWcustoRel < -RC_EPS)
									{
										
										custoRel = NEWcustoRel;
																				
										valorPad = 0;
										for (int i = 0; i < item.m; i++) {
											Padroes.padrao[i] = copia2[z].padrao[i];

											valorPad = valorPad + Padroes.padrao[i] * item.tam[i];   // cÃ¡lculo da perda gerada pela mochila q serÃ¡ o custo da var. a entrar na base 
										}

										custoMoch = retalho.Lr[j] - valorPad;

										Padroes.length = retalho.Lr[j];
										Padroes.length1 = retalho.Lr[j];

										barraUsada = 1; // usado pra indicar se foi obj. padronizado (0) ou retalho (1)
										posicao = j;

										Padroes.custoRel1 = custoRel;
										Padroes.barraUsada1 = 1;
										Padroes.geraretalho1 = 1;
										Padroes.custoMoch1 = custoMoch;
										Padroes.posicao1 = posicao; //de qual barra estou falando
										auxPosicao++;
										Padroes.posicaooriginal = auxPosicao;
										
										
										
										vetorAux2.push_back(Padroes);
									}

								}
								ProbMochila.remove(moch_constraint);
									
					}
					copia2.clear();
					copia2.resize(0);
				}
				copia2.clear();
				copia2.resize(0);

								
				numsol = vetorAux2.size();

				IloInt indice;
				cout << "num sol vale" << numsol << endl;
				sort(vetorAux2.begin(), vetorAux2.end(), ordenar);
				
					custoRel = vetorAux2[0].custoRel1;
					
			

				if (custoRel > -RC_EPS) {   // verifica se o valor da fo da mochila excede a negaÃ§Ã£o da otimalidade

					cout << "Solucao Final: " << ModelCplex.getObjValue() << endl;

					
					
					break;
				}


				_column aux;
				IloInt menor = kbest; //garantindo que vai no max ate kbest ou numsol (menor deles)
				if (numsol < kbest)
				menor = numsol;

				//IloInt menor = indice;
				vetorAux2.resize(menor);


				
				contPadroesNovos = contPadroesNovos + menor; //Menor e o nÃºmero de padrÃµes gerados por iteracao


				//cout << "menor vale" << menor;
				for (int z = 0; z < menor; z++)
				{
					//cout << "\nGonna use -> CR: " << vetorAux2[z].custoRel1 << " Pattern -> ";  
					for (int p = 0; p < newPatt.getSize(); p++)
					{
						newPatt[p] = vetorAux2[z].padrao[p];
						//cout << newPatt[p] << " ";
					}
					//getchar();
					
					
					vetorAux2[z].perda1 = vetorAux2[z].custoMoch1;
					if (vetorAux2[z].barraUsada1 == 0) {
						if (vetorAux2[z].geraretalho1 == 0)
						{
							
								Colunas.add(IloNumVar(MinPerda(vetorAux2[z].custoMoch1) + Rest_dem(newPatt) + Rest_est[vetorAux2[z].posicao1](1)));// adiciona no modelo a coluna da mochila q corta padronizado sem retalho
																																				   //vetorAux[z].length = barra.L[vetorAux[z].posicao1];
							//	cout << vetorAux2[z].custoMoch1 << "normal" << endl;
							vetorAux2[z].length = IloNum(barra.L[vetorAux2[z].posicao1]);
							//Arq5 << "Padrao normal CR: " << custoRel << endl;
							//cout << "\nNORMAL" << endl;

							
							//BRUNO
							vetorAux2[z].confirma = 1;
							vetorAux2[z].length1 = vetorAux2[z].length;

							

						}
						else {
							Colunas.add(IloNumVar(MinPerda(vetorAux2[z].custoMoch1) + Rest_dem(newPatt) + Rest_est[vetorAux2[z].posicao1](1) + Rest_balanco(1)));// adiciona no modelo a coluna da mochila q corta padronizado com retalho

																																								 //cout << "oi"; getchar(); getchar();
							
							vetorAux2[z].length = IloNum(vetorAux2[z].nbarrausada1);
							//cout << vetorAux2[z].custoMoch1 << "Padrao reduzidp CR: " << 100- vetorAux2[z].nbarrausada1 <<  endl;
							
							vetorAux2[z].confirma = 2;
							vetorAux2[z].length1 = barra.L[vetorAux2[z].posicao1];

							//vetorAux2[z].compNovoRet = compNovoRetalho;
							//env.out() << vetorAux2[z].length;																															 //vetorAux[z].length = vetorAux[z].nbarrausada1;
							//env.out() << "OPA" << endl; getchar(); getchar();

						}
					}
					else {
						Colunas.add(IloNumVar(MinPerda(vetorAux2[z].custoMoch1) + Rest_dem(newPatt) + Rest_ret[vetorAux2[z].posicao1](1) + Rest_balanco(-1)));// adiciona no modelo a coluna da mochila q corta retalho
						//cout << "\nRETALHO" << endl;																														  //env.out() << "OPA" << endl; getchar(); getchar();
																																							  //vetorAux[z].length = retalho.Lr[vetorAux[z].posicao1];
						vetorAux2[z].length = retalho.Lr[vetorAux2[z].posicao1];
						// << "\nAdd retalho CR" << custoRel << endl;
						//BRUNO
						vetorAux2[z].confirma = 3;
						vetorAux2[z].length1 = vetorAux2[z].length;
						//vetorAux2[z].compNovoRet = compNovoRetalho;
						//cout << "Guess there is a retail" << endl; getchar(); getchar();

					}
				}

				cout << "opa" << endl;
				//sort(vetorAux2.begin(), vetorAux2.end(), ordenarback);
				vetorAux.insert(vetorAux.end(), vetorAux2.begin(), vetorAux2.end());
				
				custoRel = 0;
				time(&t_aux_2);
				tempototal_aux = (t_aux_2 - t_aux_1) / double(CLOCKS_PER_SEC) * 1000;

				
			}

			time(&t_fim); //marca o tempo final
						  //tempo = difftime(t_fim, t_ini); //DiferenÃ§a dos tempos
			tempo = (t_fim - t_ini) / double(CLOCKS_PER_SEC) * 1000;

			env.out() << "Tempo total: " << tempo << endl;
			//getchar();
			//getchar();
			double perdatotal = 0, perdaporcento = 0;
			double qtde_barras_usadas = 0;
			double totalusado = 0;

			int totalpadrao = 0, totalredu = 0, totalret = 0; //comprimentos cortados

			double barras_padrao = 0, barras_reduzidas = 0, retalhos_tamanho = 0;

			int comp400 = 0, comp500 = 0, comp600 = 0; //Variáveis sobre novos retalhos
			int comp400Ret = 0, comp500Ret = 0, comp600Ret = 0; //usar retalhos em estoque


																//VARIÁVEIS PROBLEMA INTEIRO
			double perdatotalI = 0, perdaporcentoI = 0;
			double qtde_barras_usadasI = 0;
			double totalusadoI = 0;

			int totalpadraoI = 0, totalreduI = 0, totalretI = 0; //comprimentos cortados

			double barras_padraoI = 0, barras_reduzidasI = 0, retalhos_tamanhoI = 0;

			int comp400I = 0, comp500I = 0, comp600I = 0; //Variáveis sobre novos retalhos
			int comp400RetI = 0, comp500RetI = 0, comp600RetI = 0; //usar retalhos em estoque


			contadoriteracao50 += contadoriteracao;
			tempototal += tempo;

			//Imprimir tempo do oracle
			ofstream Arq7;
			//Arq7.open("Tempo_oracle.txt", ios::app);
			Arq7.open(argv[4], ios::app);
			Arq7 << tempo_oracle / contadoriteracao << endl; //precisa dividir pelo numero de iteracoes
			Arq7.close();

			//Imprimir tempo total
			ofstream Arq8;
			Arq8.open(argv[5], ios::app);
			//Arq8.open("Tempo_total", ios::app);
			Arq8 << tempo << endl;
			Arq8.close();

			//Imprimir iteracoes
			ofstream Arq9;
			Arq9.open(argv[6], ios::app);
			//Arq9.open("Iteracoes.txt", ios::app);
			Arq9 << contadoriteracao << endl;
			Arq9.close();

			//Imprimir k-medio
			ofstream Arq10;
			Arq10.open(argv[7], ios::app);
			//Arq10.open("Kmedio.txt", ios::app);
			Arq10 << (contPadroesNovos) / (contadoriteracao - 1) << endl;
			Arq10.close();

			//Imprimir perda da solucao relaxada
			ofstream Arq11;
			Arq11.open(argv[8], ios::app);
			//Arq11.open("perda_relaxada.txt", ios::app);
			Arq11 << ModelCplex.getObjValue() << endl;
			Arq11.close();

			Arq2 << "\n\nExemplo " << pp + 1 << ": PROBLEMA RELAXADO" << endl;

			Arq2 << "Tempo: " << tempo << " segundos" << endl;
			Arq2 << "Iteracoes:" << contadoriteracao << endl;
			Arq2 << "Solucao Final: " << ModelCplex.getObjValue() << endl;
			Arq2 << "Padrões novos: " << contPadroesNovos << endl;
			Arq2 << "Valor médio de k: " << (contPadroesNovos) / (contadoriteracao - 1) << endl;

			medioK50 = ((contPadroesNovos) / (contadoriteracao - 1)) + medioK50;

			IloInt auxLuiz = round(contPadroesNovos);

			contPadroesNovos2 = contPadroesNovos + contPadroesNovos2;
			contPadroesNovos = 0;


			for (int i = 0; i < Colunas.getSize(); i++) {
				vetorInt.push_back(0);
				if (ModelCplex.getValue(Colunas[i]) > 1e-6) {

					vetorInt[i] = 1;

					qtde_barras_usadas = qtde_barras_usadas + ModelCplex.getValue(Colunas[i]);
					totalusado = totalusado + vetorAux[i].length1 * ModelCplex.getValue(Colunas[i]);
					perdaporcento = (ModelCplex.getObjValue() / totalusado) * 100;

					if (vetorAux[i].confirma == 1) {
						totalpadrao += vetorAux[i].length1 * ModelCplex.getValue(Colunas[i]);
						barras_padrao += vetorAux[i].perda1*ModelCplex.getValue(Colunas[i]);
						//Arq2 << "Perda: " << vetorAux[i].perda << " X: " << ModelCplex.getValue(Colunas[i]) << endl;
					}


					else if (vetorAux[i].confirma == 2) { //significa objeto reduzido (gera retalho)
						totalredu += vetorAux[i].length1 * ModelCplex.getValue(Colunas[i]);
						if (vetorAux[i].compNovoRet == 400)
							comp400 = comp400 + ModelCplex.getValue(Colunas[i]);
						else if (vetorAux[i].compNovoRet == 500)
							comp500 = comp500 + ModelCplex.getValue(Colunas[i]);
						else
							comp600 = comp600 + ModelCplex.getValue(Colunas[i]);


						barras_reduzidas += vetorAux[i].perda1*ModelCplex.getValue(Colunas[i]);
					}
					else if (vetorAux[i].confirma == 3) {
						totalret += vetorAux[i].length1 * ModelCplex.getValue(Colunas[i]);

						if (vetorAux[i].compNovoRet == 400)
							comp400Ret = comp400Ret + ModelCplex.getValue(Colunas[i]);
						else if (vetorAux[i].compNovoRet == 500)
							comp500Ret = comp500Ret + ModelCplex.getValue(Colunas[i]);
						else
							comp600Ret = comp600Ret + ModelCplex.getValue(Colunas[i]);

						retalhos_tamanho += vetorAux[i].perda1*ModelCplex.getValue(Colunas[i]);
					}
				}


			}

			Arq2 << "\nQuantidade de barras usadas: " << qtde_barras_usadas << endl;

			Arq2 << "\nComprimento Objetos padronizados: " << totalpadrao << endl;
			Arq2 << "Comprimento Objetos reduzidos: " << totalredu << endl;

			Arq2 << "Comprimento total cortado: " << totalusado << endl;

			Arq2 << "\nPerda total: " << ModelCplex.getObjValue() << endl;
			Arq2 << "Perda por cento: " << perdaporcento << endl;

			Arq2 << "\nPerdas de barras padrão cortadas " << barras_padrao << "\n";
			Arq2 << "Perdas de barras reduzidas cortadas " << barras_reduzidas << "\n";
			Arq2 << "Perdas de retalhos em estoque cortados " << retalhos_tamanho << "\n";



			//Comprimento total cortado
			totaltotalusado += totalusado;
			totaltotalpadrao += totalpadrao;
			totaltotalredu += totalredu;
			totaltotalret += totalret;

			//Comprimentos totais perdidos
			totalbarras_padrao += barras_padrao;
			totalbarras_redu += barras_reduzidas;
			totalretalhos_tamanho += retalhos_tamanho;

			//Perdas
			totalperda += ModelCplex.getObjValue();
			totalperdaporcento += perdaporcento;

			//retalhos gerados
			totalcomp400 += comp400;
			totalcomp500 += comp500;
			totalcomp600 += comp600;

			//Retalhos usados
			totalcomp400ret += comp400Ret;
			totalcomp500ret += comp500Ret;
			totalcomp600ret += comp600Ret;


			Arq2 << "\nExemplo " << pp + 1 << ": PROBLEMA INTEIRO" << endl;
			int contador = 0;

			for (int i = 0; i < Colunas.getSize(); i++)
			{
				cout << vetorInt[i] << " ";
				if (vetorInt[i] == 1)
				{
					contador++;

				}


			}
			int y = 1;
			int t = 3;
			//auxLuiz representa o número de colunas geradas durante a geração de colunas (excluindo homogeneos pois são gerados previamente)
			IloInt KKK = round(auxLuiz / 50) + 1;
			cout << "auxluiz" << auxLuiz << endl;



			for (int i = contPadroesH; i <Colunas.getSize(); i++)
			{
				if (vetorInt[i] == 0)
				{
					if (i % KKK != 0) //significa que é par
					{
						Colunas[i].setUB(0);
					}

				}

			}

			vetorInt.clear(); //limpar pro proximo vetor



			try
			{
				time(&t_ini_int); //marca o tempo inicial do problema inteiro

				CutModel.add(IloConversion(env, Colunas, ILOINT));
				ModelCplex.setParam(IloCplex::TiLim, 100); //deixa o inteiro gastar no máximo 100s o tempo do relaxado
				ModelCplex.setParam(IloCplex::MIPSearch, 1); //1: aplicar branch and cut, 2: busca dinamica 
															 //ModelCplex.exportModel("ARTHUR.lp");
				ModelCplex.solve();
				cout << "FO" << ModelCplex.getObjValue() << endl;


				for (int i = 0; i < Colunas.getSize(); i++)
				{
					if (ModelCplex.getValue(Colunas[i]) > 1e-6)
					{
						if (i > contPadroesH - 1) //significa que um padrao não-homogeneo foi usado
						{
							contPadroesNovosUsados++;
						}
						else
							contPadroesHomogeneosUsados++;

						Arq2 << "x_" << i << "\t" << ModelCplex.getValue(Colunas[i]) << "\t";
						for (int j = 0; j < item.m; j++)
						{
							Arq2 << vetorAux[i].padrao[j] << " ";
						}
						Arq2 << "\n";
					}
				}

				//contPadroesHomogeneosUsados = Colunas.getSize() - contPadroesNovosUsados;

				contPadroesHomogeneosUsados2 = contPadroesHomogeneosUsados + contPadroesHomogeneosUsados2;
				contPadroesHomogeneosUsados = 0;


				//contPadroesH - 1;
				contPadroesH2 = contPadroesH - 1 + contPadroesH2;
				contPadroesH = 0;




				time(&t_fim_int);
				tempo_int = (t_fim_int - t_ini_int) / double(CLOCKS_PER_SEC) * 1000;
				tempototal_int += tempo_int;

				Arq2 << "Solucao Final: " << ModelCplex.getObjValue() << endl;
				Arq2 << "Tempo: " << tempo_int << endl;
				env.out() << "Solucao Final: " << ModelCplex.getObjValue() << endl;

				//Imprimir perda da solucao inteira
				ofstream Arq12;
				Arq12.open(argv[9], ios::app);
				//Arq12.open("perda_inteira.txt", ios::app);
				Arq12 << ModelCplex.getObjValue() << endl;
				Arq12.close();

				//Imprimir padroes
				ofstream Arq13;
				Arq13.open(argv[10], ios::app);
				//Arq13.open("pla_MM_U6.csv", ios::app);			

				//P Novos gerados ; P Novos Usados; P Homogeneos gerados; P Homogeneos usados\n";
				Arq13 << contPadroesNovos2 << ";" << contPadroesNovosUsados << ";" << contPadroesH2 << ";" << contPadroesHomogeneosUsados2 << ";";

				for (int i = 0; i < Colunas.getSize(); i++) {
					if (ModelCplex.getValue(Colunas[i]) > 1e-6) {
						qtde_barras_usadasI += ModelCplex.getValue(Colunas[i]);
						//Arq2 << "coluna " << i << "\tcomprimento: " << vetorAux[i].length << "\tperda: " << vetorAux[i].perda;
						//Arq2 << "\n";
						totalusadoI += vetorAux[i].length1 * ModelCplex.getValue(Colunas[i]);
						//Arq2 << "oLa" << vetorAux[i].length1 << endl;;

						perdaporcentoI = (ModelCplex.getObjValue() / totalusadoI) * 100;
						if (vetorAux[i].confirma == 1) {
							totalpadraoI += vetorAux[i].length1 * ModelCplex.getValue(Colunas[i]);
							barras_padraoI += vetorAux[i].perda1*ModelCplex.getValue(Colunas[i]);
							//Arq2 << "Perda: " << vetorAux[i].perda << " X: " << ModelCplex.getValue(Colunas[i]) << endl;
						}


						else if (vetorAux[i].confirma == 2) { //significa objeto reduzido (gera retalho)
							totalreduI += vetorAux[i].length1 * ModelCplex.getValue(Colunas[i]);
							if (vetorAux[i].compNovoRet == 400)
								comp400I = comp400I + ModelCplex.getValue(Colunas[i]);
							else if (vetorAux[i].compNovoRet == 500)
								comp500I = comp500I + ModelCplex.getValue(Colunas[i]);
							else
								comp600I = comp600I + ModelCplex.getValue(Colunas[i]);

							barras_reduzidasI += vetorAux[i].perda1*ModelCplex.getValue(Colunas[i]);
						}
						else if (vetorAux[i].confirma == 3) {
							totalretI += vetorAux[i].length1 * ModelCplex.getValue(Colunas[i]);
							if (vetorAux[i].compNovoRet == 400)
								comp400RetI = comp400RetI + ModelCplex.getValue(Colunas[i]);
							else if (vetorAux[i].compNovoRet == 500)
								comp500RetI = comp500RetI + ModelCplex.getValue(Colunas[i]);
							else
								comp600RetI = comp600RetI + ModelCplex.getValue(Colunas[i]);
							retalhos_tamanhoI += vetorAux[i].perda1*ModelCplex.getValue(Colunas[i]);
						}
					}
				}

				Arq2 << "\nQuantidade de barras usadas: " << qtde_barras_usadasI << endl;

				Arq2 << "\nComprimento Objetos padronizados: " << totalpadraoI << endl;
				Arq2 << "Comprimento Objetos reduzidos: " << totalreduI << endl;
				Arq2 << "Comprimento retalhos: " << totalretI << endl;
				Arq2 << "Comprimento total cortado: " << totalusadoI << endl;

				Arq2 << "\nPerda total: " << ModelCplex.getObjValue() << endl;
				Arq2 << "Perda por cento: " << perdaporcentoI << endl;

				Arq2 << "\nPerdas de barras padrão cortadas " << barras_padraoI << "\n";



				totaltotalusadoI += totalusadoI;
				totaltotalpadraoI += totalpadraoI;
				totaltotalreduI += totalreduI;
				totaltotalretI += totalretI;

				//Comprimentos totais perdidos
				totalbarras_padraoI += barras_padraoI;
				totalbarras_reduI += barras_reduzidasI;
				totalretalhos_tamanhoI += retalhos_tamanhoI;

				//Perdas
				totalperdaI += ModelCplex.getObjValue();
				totalperdaporcentoI += perdaporcentoI;

				//retalhos gerados
				totalcomp400I += comp400I;
				totalcomp500I += comp500I;
				totalcomp600I += comp600I;

				//Retalhos usados
				totalcomp400retI += comp400RetI;
				totalcomp500retI += comp500RetI;
				totalcomp600retI += comp600RetI;


			}
			catch (IloException& ex) {
				Arq2 << "Error: " << ex << endl;
			}
			catch (...) {
				Arq2 << "Erro" << endl;
			}








		} while (pp < -1);
		//cout << "q" << endl;

	}


	Arq2 << "\n\nDADOS PROBLEMA RELAXADO--------------------------------------------------" << endl;

	Arq2 << "COmprimento total de obj padronizados cortados: " << totaltotalpadrao << endl;
	Arq2 << "COmprimento total de obj padronizado reduzidos cortados: " << totaltotalredu << endl;
	Arq2 << "COmprimento total de retalhos cortados: " << totaltotalret << endl;

	Arq2 << "Comprimento total perdido em obj padronizados: " << totalbarras_padrao << endl;


	Arq2 << "Total perda absoluta: " << totalperda << endl;



	Arq2 << "\n\nDADOS PROBLEMA INTEIRO--------------------------------------------------" << endl;
	Arq2 << "COmprimento total de obj padronizados cortados: " << totaltotalpadraoI << endl;


	Arq2 << "Comprimento total perdido em obj padronizados: " << totalbarras_padraoI << endl;


	Arq2 << "Total perda absoluta: " << totalperdaI << endl;



}
