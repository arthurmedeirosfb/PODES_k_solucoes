#include "stdafx.h"
//#include "pch.h"
#include <iostream> // declarações da biblioteca básica de entrada e saída do C++ (le do teclado e imprime na tela)
#include <fstream>   // fluxo de arquivos
#include <ilcplex/cplex.h>
#include <ilcplex/ilocplex.h>
#include <vector>
#include<algorithm>
#include<ctime>
#include<stdlib.h>
//#include "mochila_estatica_irrestrita.cpp"

using namespace std;

#define RC_EPS 1.0e-6
#define EPS 1.0e-2

//Contador de cada iteracao xdxdxd
time_t t_ini, t_fim; //referente a time.h
double tempo;
double tempototal;

time_t t_ini_int, t_fim_int; //referente a time.h
double tempo_int;
double tempototal_int;

time_t t_aux_1, t_aux_2;
double tempo_aux;
double tempototal_aux;


/* para debugar: F5 começa, em seguida F9 para marcar, depois F10 para percorrer as linhas (não entra nas funções) ou F11 (para entrar nas fçoes. Só aperta F11 qdo estiver na fção)*/

/*typedef struct _dadosBarra{
int Nb;
int *Ib;      OBS: antes estava assim, mas como esta usando o cplex, fica mais fácil programar usando as definições de parâmetros de acordo com o cplex
int *L;        *L é um vetor que receberá um tamanho específico. Como ainda nãp sei qual é.. então põe o *
int *e;
} _dadosBarra;*/ // estrutura de dados para a leitura dos objetos em estoque (coloca o typedef antes da struct p/ depois usar apenas _dadosBarra)

typedef struct _dadosBarra {
	IloInt Nb;
	IloNumArray Ib;
	IloNumArray L;
	IloNumArray e;
} _dadosBarra;// estrutura de dados para a leitura dos objetos em estoque (coloca o typedef antes da struct p/ depois usar apenas _dadosBarra)

typedef struct _dadosRetalho {
	IloInt Nr;
	IloNumArray Ir; // indice dos ret. em estoque
	IloNumArray Lr; // comprimento dos retalhos em estoque
	IloNumArray er; // estoque dos ret. 
} _dadosRetalho;// estrutura de dados para a leitura dos retalhos em estoque 

typedef struct _dadosItem {
	IloInt m;
	IloNumArray Indice;
	IloNumArray tam;
	IloNumArray d;
} _dadosItem;// estrutura de dados para a leitura dos itens 

typedef struct _dadosNewRet {
	IloInt tipoR; // qtdde de novos tipos retalhos
	IloNumArray Inr; //Índice dos novos retalhos
	IloNumArray compRet; // Comprimento dos novos retalhos 
	IloNum qtRet; // quantidade de novos retalhos de cada tipo (U do modelo)
} _dadosNewRet;// estrutura de dados para a leitura dos novos retalhos 

typedef struct _column {
	int length;
	int perda;
	vector<int> item;
} _column;

int auxPosicao = -1; //variavel global q aumenta a medida q eu ganho vetores





struct arthur {
	vector<IloNum> padrao; //n precisa usar ponteiro
						   //IloNumArray padrao;
	IloNum barraUsada1;
	IloNum geraretalho1;
	IloNum posicao1;
	IloNum custoMoch1;
	IloNum custoRel1;
	IloNum perda1;
	IloNum length;
	IloNum posicaooriginal; //Criei pra arrumar o bug
	IloNum nbarrausada1;

	//criar a partir daqui as variáveis do bruno
	IloInt confirma;
	IloInt compNovoRet;
	IloInt length1;

	IloNum callback_obj;
};

struct arthur copia;
vector <arthur> copia2;
IloNum indicepior;
IloNum porcento = 0.02;

bool ordenar(const arthur &x, const arthur &y) { return x.custoRel1 < y.custoRel1; }
bool ordenarback(const arthur &x, const arthur &y) { return x.posicaooriginal < y.posicaooriginal; }//deixar o struct ordenado pra dps inserir no problema mestre



 /*-------Fç cálcula o min-------*/
int _fmin(int a, int b) {

	if (a > b) {
		return(b);
	}
	return(a);
}/*---------------------------*/


int qtd_resp = 0;


ILOINCUMBENTCALLBACK4(call_ksolucoes, IloNumVarArray, vetor, IloNum, tam, IloNum, qtd_user, IloCplex, MochilaCplex) //chamado quando e incumbente
{
	copia.padrao.clear();
	copia.padrao.resize(tam);
	IloNum obj;
	IloNum objFim; //obj dos nos que faltam
	IloInt indice;
	IloNum obj_nodes;
	IloNum tamanho;
	IloInt diferente = 0;

	

	if (qtd_resp == 0) //adiciona se ainda não tivermos solução
	{
		
		for (int i = 0; i < tam; i++)
		{
			
			copia.padrao[i] = round(getValue(vetor[i]));
		}
		copia.callback_obj = getObjValue();
		copia2.push_back(copia);
		indicepior = 0;
		reject();
		//cout << getObjValue() << endl;
		//getchar();
		//getchar();
		qtd_resp++;
		
	}

	else if(qtd_resp > 0)
	{
		IloInt diferentepadrao = 0;
		diferente = 0;

		IloInt diferenteobj = 0;

		if (qtd_resp < qtd_user) //Caso o vector de soluções não esteja completo adiciona
		{
			obj = getObjValue();
			diferenteobj = 0;

			for (int i = 0; i < qtd_resp; i++)
			{
				
				if (fabs(obj - copia2[i].callback_obj) > obj * 0.001)
				{

					diferenteobj++;
					//cout << "diferenteobj vale " << diferenteobj << endl;
				}
			}

			//cout << "COMPARAR " << copia2.size() << "com" << diferenteobj << endl;
			if (copia2.size() == diferenteobj)
			{
				//cout << "ADD KK" << endl;
				for (int i = 0; i < tam; i++)
				{
					//cout << getValue(vetor[i]) << " ";
				}
				//cout << "" << endl;
				//	getchar();
				//getchar();
				for (int j = 0; j < tam; j++)
				{
					copia.padrao[j] = round(getValue(vetor[j]));
				}
				copia.callback_obj = getObjValue();
				//cout << "OBJ" << copia.callback_obj << endl;
				copia2.push_back(copia);
				indice = copia2.size() - 1;

				if (copia2[indice].callback_obj < copia2[indicepior].callback_obj) //atualizar indice da pior solucao
				{
					indicepior = indice;
				}
				qtd_resp++;
				reject();
			}
			else
			{
				diferente = 0;
				for (int i = 0; i < qtd_resp; i++)
				{
					diferentepadrao = 0;
					for (int j = 0; j < tam; j++)
					{
						if (fabs(copia2[i].padrao[j] - getValue(vetor[j])) > copia2[i].padrao[j] * 0.001)
						{
							//cout << "existem" << copia2.size() << "padroes" << endl;
							//cout << "comparou" << copia2[i].padrao[j] << "com " << getValue(vetor[j]) << endl;
							diferentepadrao = 1;
							//cout << "essa linha	 acontece???" << endl;
						}
					}
					if (diferentepadrao == 1)
					{
						diferente = diferente + 1;
						//cout << "diferente vale " << diferente << endl;
						//cout << "existem" << copia2.size() << "padroes" << endl;
					}

				}

				//cout << "Caso o vector de soluções não esteja completo adiciona" << endl;
				//cout << "COMPARAR " << copia2.size() << "com " << diferente << endl;
				if (copia2.size() != diferente)
					reject();

				if (copia2.size() == diferente)
				{
					//cout << "Padrao 3 OBJ: " << getObjValue() << endl;
					for (int j = 0; j < tam; j++)
					{
						//cout << getValue(vetor[j]) << endl;
						copia.padrao[j] = round(getValue(vetor[j]));
					}
					copia.callback_obj = getObjValue();
					copia2.push_back(copia);
					indice = copia2.size() - 1;

					if (copia2[indice].callback_obj < copia2[indicepior].callback_obj) //atualizar indice da pior solucao
					{
						indicepior = indice;
					}
					qtd_resp++;
					reject();
				}

			}
		}

		obj_nodes = getBestObjValue();

		//cout << "VALOR NODE RESTANTE: " << obj_nodes << endl;

		if (qtd_resp == qtd_user) //vetor ja esta completo mas não tem necessariamente as melhores
		{

			for (int j = 0; j < qtd_resp; j++)
			{

				//cout << "\nHAHAHA " << j << "OBJ" << copia2[j].callback_obj << endl;
				for (int i = 0; i < tam; i++)
				{
					//cout << copia2[j].padrao[i] << " ";
				}
			}
			//	getchar();
			//getchar();



			//			cout << "//vetor ja esta completo mas não tem necessariamente as melhores" << endl;
			obj_nodes = getBestObjValue();
			
				//cout << "VALOR NODE RESTANTE: " << obj_nodes << endl;
			//	cout << "pior obj:" << indicepior << endl;


			IloNum LL = copia2[0].callback_obj;
			for (int i = 0; i < qtd_resp; i++)
			{
				if (copia2[i].callback_obj < LL)
				{
					LL = copia2[i].callback_obj;
					indicepior = i;
				}
			}

			//cout << "indicepior vale" << indicepior;
			if (obj_nodes <= copia2[indicepior].callback_obj) //nao encontra mais solucao boa
			{
				//cout << "abortar?" << endl;
				abort();
			}
			else
			{


				obj = getObjValue();
				//cout << "obj atual: " << obj << endl;

				obj_nodes = getBestObjValue();

				//cout << "VALOR NODE RESTANTE: " << obj_nodes << endl;



				if (obj <= copia2[indicepior].callback_obj)
				{
					//cout << "rejeitar " << obj << endl;
					reject();
				}
				else if (obj > copia2[indicepior].callback_obj)
				{

					diferente = 0;
					//				cout << "padrão sendo analisado" << endl;
					for (int j = 0; j < tam; j++)
					{
						//cout << getValue(vetor[j]) << " "; 
					}
					for (int i = 0; i < qtd_resp; i++)
					{
						diferentepadrao = 0;
						//cout << "\nCOMPAREI com " << i << endl;
						for (int j = 0; j < tam; j++)
						{
							if (fabs(copia2[i].padrao[j] - getValue(vetor[j])) > copia2[i].padrao[j] * 0.001)
							{
								//	cout << "\nantigo" << copia2[i].padrao[j] << " novo: " << getValue(vetor[j]) << endl;

								diferentepadrao = 1;
								//	cout << "essa linha	 acontece???" << endl;
							}
						}

						if (diferentepadrao == 1)
						{
							//cout << "padrao diferente" << endl;
							diferente = diferente + 1;
							//cout << "diferente vale " << diferente << endl;
							//cout << "existem" << copia2.size() << "padroes" << endl;
						}

					}
					//cout << "diferente vale" << diferente << endl;
					if (copia2.size() != diferente)
					{
						//cout << "rejeitar solucao igual" << endl;
						reject();

					}
					if (copia2.size() == diferente)
					{
						

						for (int i = 0; i < tam; i++)
						{
							//cout << getValue(vetor[i]) << " ";
							copia2[indicepior].padrao[i] = round(getValue(vetor[i]));
						}
						copia2[indicepior].callback_obj = getObjValue();
					//	cout << "vai aceitar" << endl;
						reject();
					}
					//getchar();
					//getchar();
				}
			}
		}
	}
}
//}
//	}


int verificar() //fazer depois, se tiver livre
{

	return 1;
}


/*----Principal---------*/
int main(int argc, char **argv)
{
	//IloCplex::Callback 

	ifstream Arq1;
	Arq1.open("teste3.txt");
	//Arq1.open(argv[1]);
	double perdatotal50 = 0;
	double qtde_barras_usadas50 = 0;
	double totalusado50 = 0;
	double perdaporcento50 = 0;
	double tempo50 = 0;
	double contadoriteracao50 = 0;

	double contPadroesNovos = 0;
	double contPadroesNovosUsados = 0;
	double contPadroesNovos2 = 0;

	double contPadroesH = 0;
	double contPadroesH2 = 0;
	double contPadroesHomogeneosUsados = 0;
	double contPadroesHomogeneosUsados2 = 0;

	double medioK50 = 0;

	double totalperdaporcento = 0, totalperda = 0;
	double totalbarras_padrao = 0, totalbarras_redu = 0, totalretalhos_tamanho = 0;
	double totaltotalpadrao = 0, totaltotalredu = 0, totaltotalret = 0, totaltotalusado = 0;
	double totalcomp400 = 0, totalcomp500 = 0, totalcomp600 = 0; //retalho gerado
	double totalcomp400ret = 0, totalcomp500ret = 0, totalcomp600ret = 0;

	double totalperdaporcentoI = 0, totalperdaI = 0;
	double totalbarras_padraoI = 0, totalbarras_reduI = 0, totalretalhos_tamanhoI = 0;
	double totaltotalpadraoI = 0, totaltotalreduI = 0, totaltotalretI = 0, totaltotalusadoI = 0;
	double totalcomp400I = 0, totalcomp500I = 0, totalcomp600I = 0; //retalho gerado
	double totalcomp400retI = 0, totalcomp500retI = 0, totalcomp600retI = 0;



	string lixo;
	int huehue;
	int qowp;

	vector <int> vetorInt;


	getline(Arq1, lixo);
	/* Declaração de variáveis do main*/

	_dadosBarra barra;  //a variável barra irá armazenar os dados de _dadosBarra
	_dadosItem item;    //a variável item irá armazenar os dados de _dadosItem
	_dadosRetalho retalho;
	_dadosNewRet NRet;
	IloNum alfa1, alfa2, custo;	IloNum custoR;
	alfa1 = 1.0;
	alfa2 = 1.0;
	IloEnv env; // env: var. de ambiente o cplex. Tudo do cplex tem q estar dentro desse ambiente
	cout << "q";
	//leitura(env, & barra, & item, & NRet, & retalho, & alfa1, & alfa2); //& = var no delphi 	

	IloInt kbest, numsol; //kbest numero de solucoes usuarios deseja, numsol numero de solucoes encontradas
	cout << "Quantas solucoes vc deseja obter a cada iteração (máximo)" << endl;
	cin >> kbest;
	//kbest = atoi(argv[2]);

	ofstream Arq2;
	Arq2.open("MMU0K4.txt", ios::app);
	//Arq2.open(argv[3], ios::app);

	barra.Nb = 1; //mUDAR PARA 1
	barra.Ib = IloNumArray(env, barra.Nb); // criação de um vetor com os índices das barras (o vetor de indíces das barras foi criado dentro do ambiente env do cplex e tem tamanho Nb)
	barra.L = IloNumArray(env, barra.Nb);
	barra.e = IloNumArray(env, barra.Nb);

	for (int j = 0; j < barra.Nb; j++) {
		Arq1 >> barra.Ib[j];
		Arq1 >> barra.L[j];
		Arq1 >> barra.e[j];
	}
	/*---------------------------------*/

	cout << "oi" << endl;
	getline(Arq1, lixo);

	getline(Arq1, lixo);
	getline(Arq1, lixo);

	retalho.Nr = 3; //numero de retalhos
	retalho.Ir = IloNumArray(env, retalho.Nr); // criação de um vetor com os índices dos retalhos em estoque (o vetor de indíces dos retalhos foi criado dentro do ambiente env do cplex e tem tamanho Nr)
	retalho.Lr = IloNumArray(env, retalho.Nr);
	retalho.er = IloNumArray(env, retalho.Nr);

	for (int j = 0; j < retalho.Nr; j++) {
		Arq1 >> retalho.Ir[j];
		Arq1 >> retalho.Lr[j];
		Arq1 >> retalho.er[j];
	}

	NRet.tipoR = 3;  // acesso a qtidde de novos tipos de retalhos do arquivo de leitura
	NRet.Inr = IloNumArray(env, NRet.tipoR); // criação de um vetor com os índices dos novos retalhos (o vetor de indíces foi criado dentro do ambiente env do cplex e tem tamanho TipoR)
	NRet.compRet = IloNumArray(env, NRet.tipoR);
	//NRet.qtRet = IloNumArray(env, NRet.tipoR); a

	for (int k = 0; k < NRet.tipoR; k++) {
		Arq1 >> NRet.Inr[k];
		Arq1 >> NRet.compRet[k];

	}

	Arq1 >> NRet.qtRet; //valor de u

	getline(Arq1, lixo);

	getline(Arq1, lixo);
	getline(Arq1, lixo);
	getline(Arq1, lixo);

	/*---------------------------------*/

	item.m = 60;  // acesso a qtidde de itens do arquivo de leitura
	item.Indice = IloNumArray(env, item.m); // criação de um vetor com os índices dos itens (o vetor de indíces foi criado dentro do ambiente env do cplex e tem tamanho m)
	item.tam = IloNumArray(env, item.m);
	item.d = IloNumArray(env, item.m);
	for (int pp = 0; pp < 1; pp++)
	{
		getline(Arq1, lixo);
		for (int i = 0; i < item.m; i++) {
			Arq1 >> item.Indice[i];

			
				Arq1 >> item.tam[i];
			Arq1 >> item.d[i];

				cout << item.d[i] << "hehe";


		}
		getline(Arq1, lixo);
		getline(Arq1, lixo);
		//getline(Arq1, lixo); env.out() << lixo << endl;
		//cout << "fala";
		do
		{
			time(&t_ini);

			/* CUTTING-OPTIMIZATION MODEL- Cria o modelo para o Cplex */
			IloModel CutModel(env); // declaração do modelo a ser resolvido associado ao ambiente
			IloObjective MinPerda = IloAdd(CutModel, IloMinimize(env));  // adiciona um objetivo ao modelo - Fç objetivo de minimização associado ao modelo
			IloRangeArray Rest_dem = IloAdd(CutModel, IloRangeArray(env, item.d, item.d)); // Rest_dem é o vetor de restições da demanda do modelo (neste caso, =). Esta restrição está sendo adicionada ao modelo
			IloRangeArray Rest_est = IloAdd(CutModel, IloRangeArray(env, 0.0, barra.e)); // Rest_est é o vetor de restições do estoque padronizado do modelo (neste caso, <=). Esta restrição está sendo adicionada ao modelo
			IloRangeArray Rest_ret = IloAdd(CutModel, IloRangeArray(env, 0.0, retalho.er)); // Rest_ret é o vetor de restições do estoque de retalhos do modelo (neste caso, <=). Esta restrição está sendo adicionada ao modelo
			IloNum estRet;
			//IloNumArray estRet(env, retalho.Nr); // gera um vetor com a qtdde de retalhos de cada tipo (lado direito da última restrição)
			//cout << "Hello";

			IloNum auxSoma = 0;
			for (int j = 0; j < retalho.Nr; j++) { // sempre tenho que ter a qtdde de retalhos em estoque = a qtidde q pode ser gerada 
				auxSoma = auxSoma + retalho.er[j];
				//estRet[j] = NRet.qtRet - retalho.er[j];
			}
			estRet = NRet.qtRet - auxSoma;
			IloRange Rest_balanco = IloAdd(CutModel, IloRange(env, 0.0, estRet));  // Rest_balanco é o vetor de restições do balanço de estoque do modelo (neste caso, <=). Esta restrição está sendo adicionada ao modelo
																				   //env.out() << Rest_balanco;
																				   //IloRangeArray Rest_balanco = IloAdd(CutModel, IloRangeArray(env, 0.0, estRet));
			IloNumVarArray Colunas(env); // vetor que irá armazenar as colunas (variáveis de decisão do modelo)

										 /*Montar a matriz homogenea, com retalhos e padronizados*/
			vector<_column> MATRIZ;

			struct arthur Padroes; //meu struct, usei typedef
			vector <arthur> vetorAux;

			cout << "oi";
			if (retalho.Nr > 0) {
				cout << "kk" << endl;
				for (int j = 0; j < retalho.Nr; j++) {


					for (int i = 0; i < item.m; i++) {
						if (retalho.Lr[j] >= item.tam[i]) {

							custoR = retalho.Lr[j] - 1 * item.tam[i];
							//custoR = IloNum(retalho.Lr[j] - _fmin(IloNum(retalho.Lr[j] / item.tam[i]), item.d[i])*item.tam[i]);   // cálculo da perda para calcular o custo de cada variável 	
							Colunas.add(IloNumVar(MinPerda(custoR) + Rest_dem[i](1) + Rest_ret[j](1) + Rest_balanco(-1))); //calcula os coef. das var. qdo usa ret.e adiciona: custo da var na fo, col. da matriz homogenea, coef. do estoque 	


																														   //Colunas.add(IloNumVar(MinPerda(custoR) + Rest_dem[i](_fmin(IloNum(retalho.Lr[j] / item.tam[i]), item.d[i])) + Rest_ret[j](1) + Rest_balanco(-1))); //calcula os coef. das var. qdo usa ret.e adiciona: custo da var na fo, col. da matriz homogenea, coef. do estoque 	
							Padroes.custoMoch1 = custoR;

							_column aux;
							Padroes.length = retalho.Lr[j];
							Padroes.length1 = Padroes.length;
							Padroes.padrao.resize(item.m);
							for (int k = 0; k < item.m; k++) {
								Padroes.padrao[k] = 0;
							}
							contPadroesH = contPadroesH + 1;
							Padroes.padrao[i] = 1;
							//Padroes.padrao[i] = _fmin(IloNum(retalho.Lr[j] / item.tam[i]), item.d[i]);


							Padroes.perda1 = retalho.Lr[j] - 1 * item.tam[i];
							//Padroes.perda1 = retalho.Lr[j] - _fmin(IloNum(retalho.Lr[j] / item.tam[i]), item.d[i]) * item.tam[i];

							Padroes.confirma = 3;
							//vetorAux.push_back(aux);		
							auxPosicao++;
							Padroes.posicaooriginal = auxPosicao;

							vetorAux.push_back(Padroes);

							/*for (int p = 0; p < 5; p++)
							{
							env.out() << Padroes.padrao[p] << " ";
							}
							env.out() << endl;*/
						}
					}
				}
			}

			cout << "oi";
			//cout << "oi";

			cout << "barra.nb vale" << barra.Nb << endl;
			for (int nb = 0; nb < barra.Nb; nb++) {
				for (int i = 0; i < item.m; i++) {
					custo = barra.L[nb] - 1 * item.tam[i];
					//custo = barra.L[nb] - _fmin(IloNum(barra.L[nb] / item.tam[i]), item.d[i])*item.tam[i];   // cálculo da perda para calcular o custo de cada variável 
					//Colunas.add(IloNumVar(MinPerda(custo) + Rest_dem[i](_fmin(IloNum(barra.L[nb] / item.tam[i]), item.d[i])) + Rest_est[nb](1))); //calcula os coef. das var.: custo da var na fo, col. da matriz homogenea, coef. do estoque e adiciona 
					Colunas.add(IloNumVar(MinPerda(custo) + Rest_dem[i](1) + Rest_est[nb](1)));
					cout << "custo: " << custo << endl;
					Padroes.custoMoch1 = custo;
					_column aux;
					Padroes.length = barra.L[nb];
					Padroes.length1 = Padroes.length;
					//Padroes.padrao.resize(item.m); // está adicionando as colunas na matriz (isso é feito para poder ir adicionando as demais colunas e poder imprimir os padrões no final)


					auxPosicao++;
					Padroes.posicaooriginal = auxPosicao;
					for (int j = 0; j < item.m; j++) {
						Padroes.padrao[j] = 0;

					}
					Padroes.padrao[i] = 1;
					contPadroesH = contPadroesH + 1;
					//Padroes.padrao[i] = _fmin(IloNum(barra.L[nb] / item.tam[i]), item.d[i]);

					Padroes.perda1 = barra.L[nb] - 1 * item.tam[i];

					//Padroes.perda1 = barra.L[nb] - _fmin(IloNum(barra.L[nb] / item.tam[i]), item.d[i])*item.tam[i];
					Padroes.confirma = 1;
					//vetorAux.push_back(aux);
					vetorAux.push_back(Padroes);

				}
			}
			cout << "kk";

			IloCplex ModelCplex(CutModel); // associação do modelo todo (associa o modelo ao cplex)


										   /// PATTERN-GENERATION PROBLEM - Cria o modelo para a mochila ///

			IloModel ProbMochila(env); // associação do modelo de geração de colunas ao ambiente. Modelo q gera as novas colunas
			IloObjective MaxUso = IloAdd(ProbMochila, IloMaximize(env));// fo mochila (maximizar o uso da barra)
			IloNumVarArray Var_moch(env, item.m, 0.0, IloInfinity, ILOINT); // declaração das var. da mochila q incluirá var. inteiras
			IloRangeArray moch_constraint(env); //cria a restrição da mochila, mas ainda não define qual é (será criada abaixo, pra cada tipo de barra)
			IloCplex MochilaCplex(ProbMochila); // Cria a variável que será associada a mochila 
												//MochilaCplex.setOut(env.getNullStream);
												//MochilaCplex.setParam(IloAlgorithm::setOut);
			ofstream LogFile("LogFile.txt");
			//MochilaCplex.setOut(LogFile);
			MochilaCplex.setOut(env.getNullStream());
			MochilaCplex.setWarning(env.getNullStream());

			/// Parametros da mochila

			MochilaCplex.setParam(IloCplex::SolnPoolCapacity, kbest); //aceito no maximo 5 solucoes
			MochilaCplex.setParam(IloCplex::SolnPoolIntensity, 0); //gero mais solucoes que o normal porem nao afeto desempenho
			MochilaCplex.setParam(IloCplex::SolnPoolReplace, 1); //1 = deixa as c melhor resultado na fo


																 //MochilaCplex.setParam(IloCplex::Param::Threads, 4);		não apresentou melhora /// COLUMN-GENERATION PROCEDURE ///

			IloNumArray price(env, item.m); // vetor auxiliar pra armazenar os custos duais
			IloNumArray newPatt(env, item.m); // criação de um vetor com Nb posições que irá armazenar cada cada padrão de corte proveniente do subproblema (vetor de vetores)


			IloNum custoMoch, valorPad, nbarra, barraUsada, posicao, geraRetalho;
			double custoRel = 0.0;
			IloNum NEWcustoRel;

			double piorcusto = 0.0;
			//int posicaopiorcusto; //Criei mas nem usei :/
			double contadoriteracao = 0;
			tempo = 0;
			Padroes.padrao.resize(newPatt.getSize());
			int kk;
			time(&t_aux_1);
			
			while (true) {

				vector <arthur> vetorAux2; //esse vetor vai mudar a cada iteracao

										   //	ModelCplex.exportModel("hello.lp");
										   /// OPTIMIZE OVER CURRENT PATTERNS ///

				
				ModelCplex.solve(); // resolve o prob. mestre
									//cout << "HEHE" << endl;

									//	ModelCplex.exportModel("hello.lp");
									//cout << "Problema de corte" << endl;
				contadoriteracao++;


				env.out() << "\n\nSolucao: " << ModelCplex.getObjValue() << endl;

			/*	ofstream Arq5;
				Arq5.open("blabla.txt");
				//Arq5.open(argv[6], ios::app);
				Arq5 << ModelCplex.getObjValue() << endl;
				Arq5.close();
				*/
				




				/// FIND AND ADD A NEW PATTERN ///       
				// PORQUE SOMAR O TAMANHO DO ITEM AO PRICING
				
				for (int i = 0; i < item.m; i++) { //aqui os valores da solução dual negativa (do ModelCplex) são copiados no array price
					price[i] = ModelCplex.getDual(Rest_dem[i]) + item.tam[i]; //calcula os multiplicadores Simplex (relacionados a0s itens - (valor_dual)+(tam.item)) 
				//	cout << price[i] << " ";																 //cout << price[i] << " ";
				}

				MaxUso.setLinearCoefs(Var_moch, price);// o array price é usado para definir coeficientes do objetivo no modelo ProbMochila. Obj da mochila

				custoRel = 0.0;

				for (int j = 0; j < item.m; j++) {
					newPatt[j] = 0;
				}

				Padroes.padrao.clear();

				Padroes.padrao.resize((newPatt.getSize()));
				//gera uma coluna para cada tipo de barra
				
				

				for (int j = 0; j < barra.Nb; j++) {
					if (barra.e[j] > 0) {

						moch_constraint.clear();
						moch_constraint.add(IloScalProd(item.tam, Var_moch) <= barra.L[j]);

						
						ProbMochila.add(moch_constraint); // cria a restrição da mochila

														  //MochilaCplex.use(call_diversificar(env, Var_moch, item.m, kbest, porcento));
						MochilaCplex.use(call_ksolucoes(env, Var_moch, item.m, kbest, MochilaCplex));
						//MochilaCplex.use(call_branch(env, Var_moch, item.m, kbest, MochilaCplex));

						MochilaCplex.setParam(IloCplex::Param::Preprocessing::Reduce, 1);
						MochilaCplex.setParam(IloCplex::Symmetry, 0);
						MochilaCplex.setParam(IloCplex::PreInd, 0);


						MochilaCplex.setParam(IloCplex::Param::MIP::Strategy::HeuristicFreq, -1); //HeurFreq:: - 1
						MochilaCplex.setParam(IloCplex::Param::MIP::Strategy::Probe, -1);

						qtd_resp = 0;
						
						MochilaCplex.solve(); //Resolve a geração padrão (mochila) com os coeficientes duais

						//MochilaCplex.populate();

											  //cout << "numsol vale" << numsol << endl;

						numsol = qtd_resp;
						

						for (int z = 0; z < numsol; z++) //achar um custo relativo pra cada
						{
							IloNum val = 0;
							
							for (int p = 0; p < item.m; p++)
							{

								//Padroes.padrao[p] = newPatt[p];
								
								val += copia2[z].padrao[p] * price[p];
							}

							
							//cout << MaxUso.string

							NEWcustoRel = (double)barra.L[j] - val - ModelCplex.getDual(Rest_est[j]);
							//NEWcustoRel = (double)barra.L[j] - MochilaCplex.getObjValue(z) - ModelCplex.getDual(Rest_est[j]);

							cout << "SAL ALO" << ModelCplex.getDual(Rest_est[j]) << endl;
							cout << "barra.l" << barra.L[j] << endl;
							



							if (NEWcustoRel < -RC_EPS || j == 0)
							{



								custoRel = NEWcustoRel;

								//MochilaCplex.getValues(newPatt, Var_moch, z);// se a sol. não for ótima, o padrão é copiado em newPatt e usado para construir a próxima coluna a ser inserida no modelo ModelCplex 
								//MochilaCplex.getValues(Padroes.padrao, Var_moch, z);
								//env.out() << newPatt << endl;

								valorPad = 0;
							
								for (int i = 0; i < item.m; i++) {
									valorPad = valorPad + copia2[z].padrao[i] * item.tam[i];   // cálculo da perda gerada pela mochila q será o custo da var. a entrar na base 
									Padroes.padrao[i] = copia2[z].padrao[i];
									
									//valorPad = valorPad + newPatt[i] * item.tam[i];   // cálculo da perda gerada pela mochila q será o custo da var. a entrar na base 
								}
								custoMoch = barra.L[j] - valorPad;

								

								//COloquei agora
								Padroes.length = barra.L[j];
								Padroes.length1 = barra.L[j];

								barraUsada = 0; // usado pra indicar se foi obj. padronizado (0) ou retalho (1)
								geraRetalho = 0; // indica que corta uma barra padronizada sem gerar retalho. 

								posicao = j;

								Padroes.custoRel1 = custoRel;
								Padroes.barraUsada1 = 0;
								Padroes.geraretalho1 = 0;
								Padroes.custoMoch1 = custoMoch;
								Padroes.posicao1 = posicao; //de qual barra estou falando
								auxPosicao++;
								Padroes.posicaooriginal = auxPosicao;
								//z pois estou falando 

								/*for (auto p = 0; p < newPatt.getSize(); p++)
								{
								Padroes.padrao[p] = newPatt[p];
								//cout << Padroes.padrao[p] << " ";
								}*/

								//cout << endl;
								//vetorAux.push_back(Padroes);
								vetorAux2.push_back(Padroes);
							}
						}
						ProbMochila.remove(moch_constraint);

						copia2.clear();
						copia2.resize(0);
					}
				}
				copia2.clear();
				copia2.resize(0);

				

				//gera uma coluna para cada tipo de retalho

				
				//Prepara a mochila para os objetos reduzidos - novo price
				for (int i = 0; i < item.m; i++) {
					price[i] = ModelCplex.getDual(Rest_dem[i]) + alfa1 * item.tam[i]; //calcula os multiplicadores Simplex, com o (tam.item)*alfa1 
				}

				MaxUso.setLinearCoefs(Var_moch, price);// o array price é usado para definir coeficientes do objetivo no modelo ProbMochila. Obj da mochila


				IloNum nbarra_utilizado = 0;
				//gera padrões de corte para os objetos reduzidos
				for (int j = 0; j < barra.Nb; j++) {
					if (barra.e[j] > 0) {
						if (NRet.tipoR > 0 && NRet.qtRet > 0) {
							for (int k = 0; k < NRet.tipoR; k++) {

								if (NRet.qtRet > 0) {
									nbarra = barra.L[j] - NRet.compRet[k];
									//env.out() << nbarra << endl;
									moch_constraint.clear();
									moch_constraint.add(IloScalProd(item.tam, Var_moch) <= nbarra);

									qtd_resp = 0; //nenhuma resp ainda
									copia2.resize(0);
									copia2.clear();

									//MochilaCplex.use(call_diversificar(env, Var_moch, item.m, kbest, porcento));
									MochilaCplex.use(call_ksolucoes(env, Var_moch, item.m, kbest, MochilaCplex));

									MochilaCplex.setParam(IloCplex::Param::Preprocessing::Reduce, 1);
									MochilaCplex.setParam(IloCplex::Symmetry, 0);
									MochilaCplex.setParam(IloCplex::PreInd, 0);


									MochilaCplex.setParam(IloCplex::Param::MIP::Strategy::HeuristicFreq, -1); //HeurFreq:: - 1
																											  //MochilaCplex.setParam(IloCplex::Param::MIP::Strategy::Probe, -1);


									ProbMochila.add(moch_constraint); // cria a restrição da mochila
									MochilaCplex.solve(); //Resolve a geração padrão (mochila) com os coeficientes duais
														  //MochilaCplex.populate();
														  //numsol = MochilaCplex.getSolnPoolNsolns();

									numsol = qtd_resp;
									
									

									for (int z = 0; z < numsol; z++) //achar um custo relativo pra cada
									{
										double val = 0;
										for (int p = 0; p < item.m; p++)
										{
											val += copia2[z].padrao[p] * price[p];
										}


										NEWcustoRel = alfa1 * nbarra - val - ModelCplex.getDual(Rest_est[j]) - ModelCplex.getDual(Rest_balanco);


										if (NEWcustoRel < -RC_EPS)
										{

											custoRel = NEWcustoRel;

											valorPad = 0;
											for (int i = 0; i < item.m; i++) {
												valorPad = valorPad + copia2[z].padrao[i] * item.tam[i];   // cálculo da perda gerada pela mochila q será o custo da var. a entrar na base 
												Padroes.padrao[i] = copia2[z].padrao[i];
												//valorPad = valorPad + newPatt[i] * item.tam[i];   // cálculo da perda gerada pela mochila q será o custo da var. a entrar na base 
											}

											Padroes.compNovoRet = NRet.compRet[k];
											//MochilaCplex.getValues(newPatt, Var_moch);// se a sol. não for ótima, o padrão é copiado em newPatt e usado para construir a próxima coluna a ser inserida no modelo ModelCplex 


											custoMoch = nbarra - valorPad;
											nbarra_utilizado = nbarra;
											barraUsada = 0; // usado pra indicar se foi obj. padronizado (0) ou retalho (1)
											geraRetalho = 1; // indica que corta uma barra padronizada e gera retalho. 
											posicao = j;

											Padroes.length = barra.L[j];
											Padroes.length1 = barra.L[j];

											//	env.out() << nbarra  << "Hello" << endl; 
											//getchar();
											Padroes.custoRel1 = custoRel;
											Padroes.barraUsada1 = 0;
											Padroes.geraretalho1 = 1;
											Padroes.custoMoch1 = custoMoch;
											Padroes.posicao1 = posicao; //de qual barra estou falando
											auxPosicao++;
											Padroes.posicaooriginal = auxPosicao;
											Padroes.nbarrausada1 = nbarra_utilizado;
											//z pois estou falando 


											vetorAux2.push_back(Padroes);
											//	cout<<"CR (gera)" << custoRel <<endl;
											//	getchar();
										}
									}
									ProbMochila.remove(moch_constraint);
								}
								copia2.clear();
								copia2.resize(0);
							}
						}
					}
				}

				copia2.clear();
				copia2.resize(0);
				/*
				env.out() << "Terminando retalhos\n\n" << endl;
				getchar();
				getchar();

				*/
				//cout << newPatt << endl;
				//Prepara a mochila para os objetos retalhos - novo price
				for (int i = 0; i < item.m; i++) {
					price[i] = ModelCplex.getDual(Rest_dem[i]) + alfa2 * item.tam[i]; //calcula os multiplicadores Simplex, com o (tam.item)*alfa2
				}

				MaxUso.setLinearCoefs(Var_moch, price);



				for (int j = 0; j < retalho.Nr; j++) {
					if (retalho.Nr > 0 && retalho.er[j] > EPS) {
						for (int i = 0; i < item.m; i++) {
							if (retalho.Lr[j] > item.tam[i]) {
								moch_constraint.clear();
								moch_constraint.add(IloScalProd(item.tam, Var_moch) <= retalho.Lr[j]);
								ProbMochila.add(moch_constraint); // cria a restrição da mochila

								qtd_resp = 0; //nenhuma resp ainda
								copia2.resize(0);
								copia2.clear();

								MochilaCplex.solve(); //Resolve a geração padrão (mochila) com os coeficientes duais
													  //MochilaCplex.populate();
								numsol = MochilaCplex.getSolnPoolNsolns();

								for (int z = 0; z < numsol; z++) //achar um custo relativo pra cada
								{
									NEWcustoRel = alfa2 * retalho.Lr[j] - MochilaCplex.getObjValue(z) - ModelCplex.getDual(Rest_ret[j]) + ModelCplex.getDual(Rest_balanco);
									/*for (int i = 0; i < numsol; i++)
									{
									env.out() << "\nSolution " << i << " with objective " << MochilaCplex.getObjValue(i) << endl;
									}

									env.out() << "estou no retalho: " << NEWcustoRel << endl;*/
									//getchar();
									cout << "ENTRA AQUI?" << endl;
									if (NEWcustoRel < -RC_EPS)
									{
										custoRel = NEWcustoRel;
										MochilaCplex.getValues(newPatt, Var_moch);// se a sol. não for ótima, o padrão é copiado em newPatt e usado para construir a próxima coluna a ser inserida no modelo ModelCplex 

										env.out() << "Retalho " << custoRel << endl;

										valorPad = 0;
										for (int k = 0; k < item.m; k++) {
											valorPad = valorPad + newPatt[k] * item.tam[k];   // cálculo da perda gerada pela mochila q será o custo da var. a entrar na base 
										}


										custoMoch = retalho.Lr[j] - valorPad;

										Padroes.length = retalho.Lr[j];
										Padroes.length1 = retalho.Lr[j];

										barraUsada = 1; // usado pra indicar se foi obj. padronizado (0) ou retalho (1)
										posicao = j;

										Padroes.custoRel1 = custoRel;
										Padroes.barraUsada1 = 1;
										Padroes.geraretalho1 = 1;
										Padroes.custoMoch1 = custoMoch;
										Padroes.posicao1 = posicao; //de qual barra estou falando
										auxPosicao++;
										Padroes.posicaooriginal = auxPosicao;
										//	cout <<"CR retalho = " << custoRel <<endl;
										//	getchar();




										for (int p = 0; p < newPatt.getSize(); p++)
										{
											Padroes.padrao[p] = newPatt[p];

										}
										//vetorAux.push_back(Padroes);
										vetorAux2.push_back(Padroes);
									}

								}
								ProbMochila.remove(moch_constraint);
							}
						}
					}
				}



				numsol = vetorAux2.size();

				IloInt indice = numsol;
				sort(vetorAux2.begin(), vetorAux2.end(), ordenar);
				for (int i = numsol-1; i >= 0; i--)
				{
					if (vetorAux2[i].custoRel1 >= 0)
					{
						indice = i;
					}
					
				}

				
				if(indice>0)
					vetorAux2.resize(indice);
				
				custoRel = vetorAux2[0].custoRel1;
				

				

				if (custoRel > -RC_EPS) {   // verifica se o valor da fo da mochila excede a negação da otimalidade

											//env.out() << "\n\n\nPQ NAO ENTRA AQUI"; 

					cout << "\nTERMINOU COM " << custoRel << endl;
					//getchar();
					//getchar();
					break;
				}

				
				_column aux;
				//IloInt menor = kbest; //garantindo que vai no max ate kbest ou numsol (menor deles)
				//if (numsol < kbest)
				//menor = numsol;

				IloInt menor = indice;
				//vetorAux2.resize(menor);

				contPadroesNovos = contPadroesNovos + menor; //Menor e o número de padrões gerados por iteracao


				//cout << "\nmenor vale" << menor << endl;
				//getchar();

				for (int z = 0; z < menor; z++)
				{
					cout << "CR: " << vetorAux2[z].custoRel1 << endl;
					
					for (int p = 0; p < newPatt.getSize(); p++)
					{
						newPatt[p] = vetorAux2[z].padrao[p];
						
					}
					

					//vetorAux[z].perda1 = vetorAux[z].custoMoch1;
					vetorAux2[z].perda1 = vetorAux2[z].custoMoch1;
					//cout << "perdinnha" << vetorAux2[z].custoMoch1 << endl;
					if (vetorAux2[z].barraUsada1 == 0) {
						if (vetorAux2[z].geraretalho1 == 0)
						{
							Colunas.add(IloNumVar(MinPerda(vetorAux2[z].custoMoch1) + Rest_dem(newPatt) + Rest_est[vetorAux2[z].posicao1](1)));// adiciona no modelo a coluna da mochila q corta padronizado sem retalho
																																			   //vetorAux[z].length = barra.L[vetorAux[z].posicao1];
							vetorAux2[z].length = IloNum(barra.L[vetorAux2[z].posicao1]);
							//cout << "Perda: " << vetorAux2[z].custoMoch1 << "\n" << endl;
							//BRUNO
							vetorAux2[z].confirma = 1;
							vetorAux2[z].length1 = vetorAux2[z].length;

							/*for (int p = 0; p < newPatt.getSize(); p++)
							{
							env.out() << vetorAux2[z].padrao[p] << " ";
							}
							env.out() << "   CR: " << vetorAux2[z].custoRel1 << " Perda " << vetorAux2[z].custoMoch1 << endl;
							cout << "Barra usada" << vetorAux2[z].barraUsada1 << " lenght" << vetorAux2[z].length << endl;*/

						}
						else {
							Colunas.add(IloNumVar(MinPerda(vetorAux2[z].custoMoch1) + Rest_dem(newPatt) + Rest_est[vetorAux2[z].posicao1](1) + Rest_balanco(1)));// adiciona no modelo a coluna da mochila q corta padronizado com retalho

							cout << vetorAux2[z].custoMoch1 << "Padrao reduzidp CR: " << 100 - vetorAux2[z].nbarrausada1 << endl;
							vetorAux2[z].length = IloNum(vetorAux2[z].nbarrausada1);

							//BRUNO
							vetorAux2[z].confirma = 2;
							vetorAux2[z].length1 = barra.L[vetorAux2[z].posicao1];

							//vetorAux2[z].compNovoRet = compNovoRetalho;
							//env.out() << vetorAux2[z].length;																															 //vetorAux[z].length = vetorAux[z].nbarrausada1;
							//env.out() << "OPA" << endl; getchar(); getchar();

						}
					}
					else {
						Colunas.add(IloNumVar(MinPerda(vetorAux2[z].custoMoch1) + Rest_dem(newPatt) + Rest_ret[vetorAux2[z].posicao1](1) + Rest_balanco(-1)));// adiciona no modelo a coluna da mochila q corta retalho
																																							  //cout << "\nRETALHO" << endl;																														  //env.out() << "OPA" << endl; getchar(); getchar();
						cout << "\nRETALHO" << endl;																																	  //vetorAux[z].length = retalho.Lr[vetorAux[z].posicao1];
						vetorAux2[z].length = retalho.Lr[vetorAux2[z].posicao1];

						//BRUNO
						vetorAux2[z].confirma = 3;
						vetorAux2[z].length1 = vetorAux2[z].length;
						//vetorAux2[z].compNovoRet = compNovoRetalho;
						//cout << "Guess there is a retail" << endl; getchar(); getchar();

					}
				}

				cout << "ESPERA" << endl;
				
			

				//sort(vetorAux2.begin(), vetorAux2.end(), ordenarback);
				vetorAux.insert(vetorAux.end(), vetorAux2.begin(), vetorAux2.end());

				custoRel = 0;
				time(&t_aux_2);
				tempototal_aux = (t_aux_2 - t_aux_1) / double(CLOCKS_PER_SEC) * 1000;
			/*
				ofstream Arq6;
				Arq6.open("Padroes_MAU3K1.txt", ios::app);
				//Arq6.open(argv[7],ios::app);
				Arq6 << tempototal_aux << endl;
				Arq6.close();
				*/
			}

			MochilaCplex.end();

			ProbMochila.end();

			moch_constraint.end();

			MaxUso.end();
			Var_moch.end();



			time(&t_fim); //marca o tempo final
						  //tempo = difftime(t_fim, t_ini); //DiferenÃ§a dos tempos
			tempo = (t_fim - t_ini) / double(CLOCKS_PER_SEC) * 1000;

			//env.out() << "Tempo total: " << tempo << endl;

			double perdatotal = 0, perdaporcento = 0;
			double qtde_barras_usadas = 0;
			double totalusado = 0;

			int totalpadrao = 0, totalredu = 0, totalret = 0; //comprimentos cortados

			double barras_padrao = 0, barras_reduzidas = 0, retalhos_tamanho = 0;

			int comp400 = 0, comp500 = 0, comp600 = 0; //Variáveis sobre novos retalhos
			int comp400Ret = 0, comp500Ret = 0, comp600Ret = 0; //usar retalhos em estoque


																//VARIÁVEIS PROBLEMA INTEIRO
			double perdatotalI = 0, perdaporcentoI = 0;
			double qtde_barras_usadasI = 0;
			double totalusadoI = 0;

			int totalpadraoI = 0, totalreduI = 0, totalretI = 0; //comprimentos cortados

			double barras_padraoI = 0, barras_reduzidasI = 0, retalhos_tamanhoI = 0;

			int comp400I = 0, comp500I = 0, comp600I = 0; //Variáveis sobre novos retalhos
			int comp400RetI = 0, comp500RetI = 0, comp600RetI = 0; //usar retalhos em estoque


			contadoriteracao50 += contadoriteracao;
			tempototal += tempo;


			Arq2 << "\n\nExemplo " << pp + 1 << ": PROBLEMA RELAXADO" << endl;

			Arq2 << "Tempo: " << tempo << " segundos" << endl;
			Arq2 << "Iteracoes:" << contadoriteracao << endl;
			Arq2 << "Solucao Final: " << ModelCplex.getObjValue() << endl;
			Arq2 << "Padrões novos: " << contPadroesNovos << endl;
			Arq2 << "Valor médio de k: " << (contPadroesNovos) / (contadoriteracao - 1) << endl;

			medioK50 = ((contPadroesNovos) / (contadoriteracao - 1)) + medioK50;

			//ofstream teste;
			//teste.open("Padroes_teste.txt", ios::app);
			//teste << "Padrão: " << contPadroesNovos; 

			//env.out() << "\nPadrão: " << contPadroesNovos;
			IloInt auxLuiz = round(contPadroesNovos);
			contPadroesNovos2 = contPadroesNovos2 + contPadroesNovos;
			contPadroesNovos = 0;

			//Comentar esse for pra ver se diminui o erro. Arquivo mt grande, ta travando o processamento



			for (int i = 0; i < Colunas.getSize(); i++) {
				vetorInt.push_back(0);
				if (ModelCplex.getValue(Colunas[i]) > 1e-6) {

					vetorInt[i] = 1; //vale 1 se estiver na solucao continua

					qtde_barras_usadas = qtde_barras_usadas + ModelCplex.getValue(Colunas[i]);
					totalusado = totalusado + vetorAux[i].length1 * ModelCplex.getValue(Colunas[i]);
					perdaporcento = (ModelCplex.getObjValue() / totalusado) * 100;

					if (vetorAux[i].confirma == 1) {
						totalpadrao += vetorAux[i].length1 * ModelCplex.getValue(Colunas[i]);
						barras_padrao += vetorAux[i].perda1*ModelCplex.getValue(Colunas[i]);

					}


					else if (vetorAux[i].confirma == 2) { //significa objeto reduzido (gera retalho)
						totalredu += vetorAux[i].length1 * ModelCplex.getValue(Colunas[i]);
						if (vetorAux[i].compNovoRet == 400)
							comp400 = comp400 + ModelCplex.getValue(Colunas[i]);
						else if (vetorAux[i].compNovoRet == 500)
							comp500 = comp500 + ModelCplex.getValue(Colunas[i]);
						else
							comp600 = comp600 + ModelCplex.getValue(Colunas[i]);


						barras_reduzidas += vetorAux[i].perda1*ModelCplex.getValue(Colunas[i]);
					}
					else if (vetorAux[i].confirma == 3) {
						totalret += vetorAux[i].length1 * ModelCplex.getValue(Colunas[i]);

						if (vetorAux[i].compNovoRet == 400)
							comp400Ret = comp400Ret + ModelCplex.getValue(Colunas[i]);
						else if (vetorAux[i].compNovoRet == 500)
							comp500Ret = comp500Ret + ModelCplex.getValue(Colunas[i]);
						else
							comp600Ret = comp600Ret + ModelCplex.getValue(Colunas[i]);

						retalhos_tamanho += vetorAux[i].perda1*ModelCplex.getValue(Colunas[i]);
					}
				}

			}

			Arq2 << "\nQuantidade de barras usadas: " << qtde_barras_usadas << endl;

			Arq2 << "\nComprimento Objetos padronizados: " << totalpadrao << endl;
			Arq2 << "Comprimento Objetos reduzidos: " << totalredu << endl;
			Arq2 << "Comprimento retalhos: " << totalret << endl;
			Arq2 << "Comprimento total cortado: " << totalusado << endl;

			Arq2 << "\nPerda total: " << ModelCplex.getObjValue() << endl;
			Arq2 << "Perda por cento: " << perdaporcento << endl;

			Arq2 << "\nPerdas de barras padrão cortadas " << barras_padrao << "\n";
			Arq2 << "Perdas de barras reduzidas cortadas " << barras_reduzidas << "\n";
			Arq2 << "Perdas de retalhos em estoque cortados " << retalhos_tamanho << "\n";


			Arq2 << "\nRetalhos de 400 gerados: " << comp400 << endl;
			Arq2 << "Retalhos de 500 gerados: " << comp500 << endl;
			Arq2 << "Retalhos de 600 gerados: " << comp600 << endl;

			Arq2 << "\nRetalhos de 400 usados: " << comp400Ret << endl;
			Arq2 << "Retalhos de 500 usados: " << comp500Ret << endl;
			Arq2 << "Retalhos de 600 usados: " << comp600Ret << endl;

			//Comprimento total cortado
			totaltotalusado += totalusado;
			totaltotalpadrao += totalpadrao;
			totaltotalredu += totalredu;
			totaltotalret += totalret;

			//Comprimentos totais perdidos
			totalbarras_padrao += barras_padrao;
			totalbarras_redu += barras_reduzidas;
			totalretalhos_tamanho += retalhos_tamanho;

			//Perdas
			totalperda += ModelCplex.getObjValue();
			totalperdaporcento += perdaporcento;

			//retalhos gerados
			totalcomp400 += comp400;
			totalcomp500 += comp500;
			totalcomp600 += comp600;

			//Retalhos usados
			totalcomp400ret += comp400Ret;
			totalcomp500ret += comp500Ret;
			totalcomp600ret += comp600Ret;



			Arq2 << "\nExemplo " << pp + 1 << ": PROBLEMA INTEIRO" << endl;

			int contador = 0;

			for (int i = 0; i < Colunas.getSize(); i++)
			{
				//cout << vetorInt[i] << " ";
				if (vetorInt[i] == 1)
				{
					contador++;

				}


			}
			//cout << "\ncontador vale" << contador;
			//getchar();
			//getchar();
			int y = 1;
			int t = 3;
			//auxLuiz representa o número de colunas geradas durante a geração de colunas (excluindo homogeneos pois são gerados previamente)
			IloInt KKK = round(auxLuiz / 50) + 1;
			//cout << "auxluiz" << auxLuiz << endl;

			//cout << "kkk VALE" << KKK << endl;
			//getchar();
			//getchar();

			for (int i = contPadroesH; i < Colunas.getSize(); i++)
			{
				if (vetorInt[i] == 0)
				{
					if (i % KKK != 0)
					{
						Colunas[i].setUB(0);
					}

				}

				//CutModel.remove(Colunas[i]); não funcionou
			}

			vetorInt.clear(); //limpar pro proximo vetor

			try
			{
				time(&t_ini_int); //marca o tempo inicial do problema inteiro
				CutModel.add(IloConversion(env, Colunas, ILOINT));
				ModelCplex.setParam(IloCplex::TiLim, 5); //deixa o inteiro gastar no máximo 100s o tempo do relaxado
				ModelCplex.setParam(IloCplex::MIPSearch, 1); //1: aplicar branch and cut, 2: busca dinamica 
															 //ModelCplex.exportModel("ARTHUR.lp");
				ModelCplex.solve();

				for (int i = 0; i < Colunas.getSize(); i++)
				{
					if (ModelCplex.getValue(Colunas[i]) > 1e-6)
					{
						if (i > contPadroesH - 1) //significa que um padrao não-homogeneo foi usado
						{
							contPadroesNovosUsados++;
						}
						else
							contPadroesHomogeneosUsados++;

						Arq2 << "x_" << i << "\t" << ModelCplex.getValue(Colunas[i]) << "\t";
						for (int j = 0; j < item.m; j++)
						{
							Arq2 << vetorAux[i].padrao[j] << " ";
						}
						Arq2 << "\n";
					}
				}

				contPadroesHomogeneosUsados2 = contPadroesHomogeneosUsados + contPadroesHomogeneosUsados2;
				contPadroesHomogeneosUsados = 0;

				contPadroesH - 1;
				contPadroesH2 = contPadroesH - 1 + contPadroesH2;
				contPadroesH = 0;


				time(&t_fim_int); //marca o tempo final
								  //tempo = difftime(t_fim, t_ini); //DiferenÃ§a dos tempos
				tempo_int = (t_fim_int - t_ini_int) / double(CLOCKS_PER_SEC) * 1000;
				tempototal_int += tempo_int;

				//teste << " tempo: " <<  tempo_int << endl;

				//env.out() << "Solucao Final inteiro: " << ModelCplex.getObjValue() << endl;

				Arq2 << "Solucao Final inteiro: " << ModelCplex.getObjValue() << endl;
				Arq2 << "Tempo inteiro: " << tempo_int << endl;



				for (int i = 0; i < Colunas.getSize(); i++) {
					if (ModelCplex.getValue(Colunas[i]) > 1e-6) {
						qtde_barras_usadasI += ModelCplex.getValue(Colunas[i]);
						//Arq2 << "coluna " << i << "\tcomprimento: " << vetorAux[i].length << "\tperda: " << vetorAux[i].perda;
						//Arq2 << "\n";
						totalusadoI += vetorAux[i].length1 * ModelCplex.getValue(Colunas[i]);
						//Arq2 << "oLa" << vetorAux[i].length1 << endl;;

						perdaporcentoI = (ModelCplex.getObjValue() / totalusadoI) * 100;
						if (vetorAux[i].confirma == 1) {
							totalpadraoI += vetorAux[i].length1 * ModelCplex.getValue(Colunas[i]);
							barras_padraoI += vetorAux[i].perda1*ModelCplex.getValue(Colunas[i]);
							//Arq2 << "Perda: " << vetorAux[i].perda << " X: " << ModelCplex.getValue(Colunas[i]) << endl;
						}


						else if (vetorAux[i].confirma == 2) { //significa objeto reduzido (gera retalho)
							totalreduI += vetorAux[i].length1 * ModelCplex.getValue(Colunas[i]);
							if (vetorAux[i].compNovoRet == 400)
								comp400I = comp400I + ModelCplex.getValue(Colunas[i]);
							else if (vetorAux[i].compNovoRet == 500)
								comp500I = comp500I + ModelCplex.getValue(Colunas[i]);
							else
								comp600I = comp600I + ModelCplex.getValue(Colunas[i]);

							barras_reduzidasI += vetorAux[i].perda1*ModelCplex.getValue(Colunas[i]);
						}
						else if (vetorAux[i].confirma == 3) {
							totalretI += vetorAux[i].length1 * ModelCplex.getValue(Colunas[i]);
							if (vetorAux[i].compNovoRet == 400)
								comp400RetI = comp400RetI + ModelCplex.getValue(Colunas[i]);
							else if (vetorAux[i].compNovoRet == 500)
								comp500RetI = comp500RetI + ModelCplex.getValue(Colunas[i]);
							else
								comp600RetI = comp600RetI + ModelCplex.getValue(Colunas[i]);
							retalhos_tamanhoI += vetorAux[i].perda1*ModelCplex.getValue(Colunas[i]);
						}
					}
				}

				Arq2 << "\nQuantidade de barras usadas: " << qtde_barras_usadasI << endl;

				Arq2 << "\nComprimento Objetos padronizados: " << totalpadraoI << endl;
				Arq2 << "Comprimento Objetos reduzidos: " << totalreduI << endl;
				Arq2 << "Comprimento retalhos: " << totalretI << endl;
				Arq2 << "Comprimento total cortado: " << totalusadoI << endl;

				Arq2 << "\nPerda total: " << ModelCplex.getObjValue() << endl;
				Arq2 << "Perda por cento: " << perdaporcentoI << endl;

				Arq2 << "\nPerdas de barras padrão cortadas " << barras_padraoI << "\n";
				Arq2 << "Perdas de barras reduzidas cortadas " << barras_reduzidasI << "\n";
				Arq2 << "Perdas de retalhos em estoque cortados " << retalhos_tamanhoI << "\n";


				Arq2 << "\nRetalhos de 400 gerados: " << comp400I << endl;
				Arq2 << "Retalhos de 500 gerados: " << comp500I << endl;
				Arq2 << "Retalhos de 600 gerados: " << comp600I << endl;

				Arq2 << "\nRetalhos de 400 usados: " << comp400RetI << endl;
				Arq2 << "Retalhos de 500 usados: " << comp500RetI << endl;
				Arq2 << "Retalhos de 600 usados: " << comp600RetI << endl;

				totaltotalusadoI += totalusadoI;
				totaltotalpadraoI += totalpadraoI;
				totaltotalreduI += totalreduI;
				totaltotalretI += totalretI;

				//Comprimentos totais perdidos
				totalbarras_padraoI += barras_padraoI;
				totalbarras_reduI += barras_reduzidasI;
				totalretalhos_tamanhoI += retalhos_tamanhoI;

				//Perdas
				totalperdaI += ModelCplex.getObjValue();
				totalperdaporcentoI += perdaporcentoI;

				//retalhos gerados
				totalcomp400I += comp400I;
				totalcomp500I += comp500I;
				totalcomp600I += comp600I;

				//Retalhos usados
				totalcomp400retI += comp400RetI;
				totalcomp500retI += comp500RetI;
				totalcomp600retI += comp600RetI;


			}
			catch (IloException& ex) {
				Arq2 << "Error: " << ex << endl;
			}
			catch (...) {
				Arq2 << "Erro" << endl;
			}


			Rest_dem.end();

			Rest_est.end();

			Colunas.end();


			MinPerda.end();

			CutModel.end();






		} while (pp < -1);
		//cout << "q" << endl;

	}
	//getchar();


	Arq2 << "\n\nDADOS PROBLEMA RELAXADO--------------------------------------------------" << endl;

	Arq2 << "COmprimento total de obj padronizados cortados: " << totaltotalpadrao << endl;
	Arq2 << "COmprimento total de obj padronizado reduzidos cortados: " << totaltotalredu << endl;
	Arq2 << "COmprimento total de retalhos cortados: " << totaltotalret << endl;

	Arq2 << "Comprimento total perdido em obj padronizados: " << totalbarras_padrao << endl;
	Arq2 << "Comprimento total perdido em obj padronizados reduzidos: " << totalbarras_redu << endl;
	Arq2 << "Comprimento total perdido em retalhos: " << totalretalhos_tamanho << endl;

	Arq2 << "Total perda absoluta: " << totalperda << endl;



	Arq2 << "\n\nDADOS PROBLEMA INTEIRO--------------------------------------------------" << endl;
	Arq2 << "COmprimento total de obj padronizados cortados: " << totaltotalpadraoI << endl;
	Arq2 << "COmprimento total de obj padronizados reduzidos cortados: " << totaltotalreduI << endl;
	Arq2 << "COmprimento total de retalhos cortados: " << totaltotalretI << endl;

	Arq2 << "Comprimento total perdido em obj padronizados: " << totalbarras_padraoI << endl;
	Arq2 << "Comprimento total perdido em obj padronizados reduzidos: " << totalbarras_reduI << endl;
	Arq2 << "Comprimento total perdido em retalhos: " << totalretalhos_tamanhoI << endl;

	Arq2 << "Total perda absoluta: " << totalperdaI << endl;






	ofstream Arq3;
	Arq3.open("MM_AGORA_MEDIA.txt", ios::app);
	//Arq3.open(argv[4], ios::app);

	ofstream Arq4;
	Arq4.open("MM_planilha.csv", ios::app);
	//Arq4.open(argv[5], ios::app);
	Arq4 << "\n\nRelaxado ;Tempo ; Iterações ; K ; K medio \n";
	Arq4 << ";" << tempototal / 50 << ";" << contadoriteracao50 / 50 << ";" << kbest << ";" << medioK50 / 50;

	Arq4 << "\nInteiro ;Tempo ; P Novos gerados ; P Novos Usados; P Homogeneos gerados; P Homogeneos usados\n";
	Arq4 << ";" << tempototal_int / 50 << ";" << contPadroesNovos2 / 50 << ";" << contPadroesNovosUsados / 50 << ";" << contPadroesH2 / 50 << ";" << contPadroesHomogeneosUsados2 / 50 << ";";

	Arq4.close();


	Arq3 << "\nTempo médio de execução relaxado: " << tempototal / 50 << " segundos" << endl;
	Arq3 << "Iteracoes: " << contadoriteracao50 / 50 << endl;
	Arq3 << "Valor teórico de k: " << kbest << endl;
	Arq3 << "Valor real de k: " << medioK50 / 50 << endl;


	Arq3 << "\nTempo médio de execução inteiro: " << tempototal_int / 50 << " segundos" << endl;
	Arq3 << "Padrões novos gerados: " << contPadroesNovos2 / 50 << endl;
	Arq3 << "Padrões novos usados: " << contPadroesNovosUsados / 50 << endl;
	Arq3 << "Padrões homogeneos gerados: " << contPadroesH2 / 50 << endl;
	Arq3 << "Padrões homogeneos usados: " << contPadroesHomogeneosUsados2 / 50 << endl;



	Arq3 << "\n\nDADOS PROBLEMA RELAXADO--------------------------------------------------" << endl;
	Arq3 << "\nComprimento médio cortado: " << totaltotalusado / 50 << endl;
	Arq3 << "COmprimento médio total de obj padronizados cortados: " << totaltotalpadrao / 50 << endl;
	Arq3 << "COmprimento médio total de obj padronizados reduzidos cortados: " << totaltotalredu / 50 << endl;
	Arq3 << "COmprimento médio total de retalhos cortados: " << totaltotalret / 50 << endl;

	Arq3 << "\nComprimento médio total perdido em obj padronizados: " << totalbarras_padrao / 50 << endl;
	Arq3 << "Comprimento médio total perdido em obj reduzidos: " << totalbarras_redu / 50 << endl;
	Arq3 << "Comprimento médio total perdido em retalhos: " << totalretalhos_tamanho / 50 << endl;

	Arq3 << "\nPerda média em %: " << totalperdaporcento / 50 << endl;
	Arq3 << "Perda média absoluta: " << totalperda / 50 << endl;

	Arq3 << "\nMédia de retalhos de 400 gerados: " << totalcomp400 / 50 << endl;
	Arq3 << "Média de retalhos de 500 gerados: " << totalcomp500 / 50 << endl;
	Arq3 << "Média de retalhos de 600 gerados: " << totalcomp600 / 50 << endl;

	Arq3 << "\nMédia de retalhos de 400 usados: " << totalcomp400ret / 50 << endl;
	Arq3 << "Média de retalhos de 500 usados: " << totalcomp500ret / 50 << endl;
	Arq3 << "Média de retalhos de 600 usados: " << totalcomp600ret / 50 << endl;



	Arq3 << "\n\nDADOS PROBLEMA INTEIRO--------------------------------------------------" << endl;
	Arq3 << "\nComprimento médio cortado: " << totaltotalusadoI / 50 << endl;
	Arq3 << "COmprimento médio total de obj padronizados cortados: " << totaltotalpadraoI / 50 << endl;
	Arq3 << "COmprimento médio total de obj padronizados reduzidos cortados: " << totaltotalreduI / 50 << endl;
	Arq3 << "COmprimento médio total de retalhos cortados: " << totaltotalretI / 50 << endl;

	Arq3 << "\nComprimento médio total perdido em obj padronizados: " << totalbarras_padraoI / 50 << endl;
	Arq3 << "Comprimento médio total perdido em obj reduzidos: " << totalbarras_reduI / 50 << endl;
	Arq3 << "Comprimento médio total perdido em retalhos: " << totalretalhos_tamanhoI / 50 << endl;

	Arq3 << "\nPerda média em %: " << totalperdaporcentoI / 50 << endl;
	Arq3 << "Perda média absoluta: " << totalperdaI / 50 << endl;

	Arq3 << "\nMédia de retalhos de 400 gerados: " << totalcomp400I / 50 << endl;
	Arq3 << "Média de retalhos de 500 gerados: " << totalcomp500I / 50 << endl;
	Arq3 << "Média de retalhos de 600 gerados: " << totalcomp600I / 50 << endl;

	Arq3 << "\nMédia de retalhos de 400 usados: " << totalcomp400retI / 50 << endl;
	Arq3 << "Média de retalhos de 500 usados: " << totalcomp500retI / 50 << endl;
	Arq3 << "Média de retalhos de 600 usados: " << totalcomp600retI / 50 << endl;

	Arq3.close();

}